#!/usr/bin/env node
// ─────────────────────────────────────────────────────────────
// زرع كلمة مرور ويب لمستخدم موجود (لأول دخول للمدير بعد النشر)
// الاستخدام:  node scripts/set-admin-password.mjs <username> <password>
// ─────────────────────────────────────────────────────────────
import { Pool } from "pg";
import { randomBytes, scryptSync } from "node:crypto";
import { readFileSync } from "node:fs";

// قراءة DATABASE_URL من ملف .env يدوياً (بدون اعتماديات)
function loadEnv() {
  try {
    const raw = readFileSync(new URL("../.env", import.meta.url), "utf8");
    for (const line of raw.split("\n")) {
      const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
    }
  } catch {
    /* لا ملف .env — نعتمد على بيئة النظام */
  }
}
loadEnv();

const [username, password] = process.argv.slice(2);
if (!username || !password) {
  console.error("الاستخدام: node scripts/set-admin-password.mjs <username> <password>");
  process.exit(1);
}
if (password.length < 4) {
  console.error("كلمة المرور يجب أن تكون 4 أحرف على الأقل");
  process.exit(1);
}

const cs = process.env.CERAM_DATABASE_URL || process.env.DATABASE_URL;
if (!cs || cs.startsWith("file:")) {
  console.error("خطأ: DATABASE_URL غير مضبوط أو يشير لملف — عدّل ملف .env أولاً");
  process.exit(1);
}

const salt = randomBytes(16).toString("hex");
const hash = scryptSync(password, salt, 64).toString("hex");
const stored = `${salt}:${hash}`;

const pool = new Pool({ connectionString: cs });
try {
  const u = await pool.query(
    "SELECT id, username, role, active FROM users WHERE LOWER(username) = LOWER($1)",
    [username.replace(/@/g, "").trim()]
  );
  if (u.rows.length === 0) {
    console.error(`لا يوجد مستخدم باسم «${username}» في قاعدة البوت`);
    process.exit(1);
  }
  const user = u.rows[0];
  await pool.query(
    `INSERT INTO web_auth (user_id, password_hash, updated_at)
     VALUES ($1, $2, NOW())
     ON CONFLICT (user_id) DO UPDATE SET password_hash = $2, updated_at = NOW()`,
    [user.id, stored]
  );
  await pool.query("DELETE FROM web_sessions WHERE user_id = $1", [user.id]);
  console.log(`✔ تم تعيين كلمة مرور الويب للمستخدم @${user.username} (الفئة: ${user.role})`);
  console.log("  يمكنه الآن تسجيل الدخول من التطبيق.");
} catch (err) {
  console.error("فشل:", err.message);
  process.exit(1);
} finally {
  await pool.end();
}
