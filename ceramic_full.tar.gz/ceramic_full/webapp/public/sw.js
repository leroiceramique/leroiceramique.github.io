// عامل خدمة PWA — مخزون السيراميك
// الإستراتيجية:
//  • الغلاف (الصفحة/الأصول الثابتة): cache-first مع تحديث خلفي
//  • /api/*: network-only (البيانات حية ومشتركة مع البوت) مع
//    رسالة Offline واضحة عند غياب الشبكة
const CACHE = "ceramweb-v1";
const SHELL = ["/", "/icons/icon-192.png", "/icons/icon-512.png", "/manifest.webmanifest"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // طلبات API: الشبكة أولاً — بلا كاش للبيانات الحية
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(
      fetch(req).catch(
        () =>
          new Response(
            JSON.stringify({ ok: false, error: "لا يوجد اتصال — أعد المحاولة عند عودة الشبكة" }),
            { status: 503, headers: { "Content-Type": "application/json; charset=utf-8" } }
          )
      )
    );
    return;
  }

  // الأصول والغلاف: كاش أولاً مع تحديث خلفي
  event.respondWith(
    caches.match(req).then((cached) => {
      const fresh = fetch(req)
        .then((res) => {
          if (res && res.status === 200 && res.type === "basic") {
            const copy = res.clone();
            caches.open(CACHE).then((c) => c.put(req, copy));
          }
          return res;
        })
        .catch(() => cached);
      return cached || fresh;
    })
  );
});
