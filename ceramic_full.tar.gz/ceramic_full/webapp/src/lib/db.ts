// ═══════════════════════════════════════════════════════════════
//  طبقة قاعدة البيانات — pg (node-postgres) مباشرة، بلا ORM.
//  السبب: التطبيق يتشارك قاعدة PostgreSQL مع البوت، والمخطط يملكه
//  البوت (SCHEMA_SQL) — استعلامات SQL خام مطابقة لأسلوب البوت
//  تمنع أي تعارض ترحيلات وتضمن نفس الدلالات حرفياً.
//  في التطوير: DATABASE_URL يشير إلى خدمة PGlite المحلية (5433).
//  في الإنتاج: يشير إلى قاعدة بيانات البوت على السيرفر.
// ═══════════════════════════════════════════════════════════════
import { Pool } from "pg";
import type { QueryResultRow } from "pg";
import { ENSURE_SQL, DEFAULT_PERMS } from "./schema";

const globalForPg = globalThis as unknown as { ceramPool?: Pool };

export const pool =
  globalForPg.ceramPool ??
  new Pool({
    // CERAM_DATABASE_URL له الأولوية لأن بيئة الاستضافة قد تفرض
    // DATABASE_URL خاصاً بها (كما في معاينة التطوير هنا).
    connectionString:
      process.env.CERAM_DATABASE_URL ||
      process.env.DATABASE_URL ||
      "postgres://127.0.0.1:5433/main",
    max: 10,
    idleTimeoutMillis: 30_000,
  });

if (process.env.NODE_ENV !== "production") globalForPg.ceramPool = pool;

// ── ضمان المخطط مرة واحدة لكل عملية تشغيل (idempotent) ──
const globalForEnsure = globalThis as unknown as {
  ceramEnsure?: Promise<void>;
};

export function ensureSchema(): Promise<void> {
  if (!globalForEnsure.ceramEnsure) {
    globalForEnsure.ceramEnsure = (async () => {
      await pool.query(ENSURE_SQL);
      for (const [role, perm] of DEFAULT_PERMS) {
        await pool.query(
          "INSERT INTO role_permissions (role, perm, enabled) VALUES ($1, $2, TRUE) ON CONFLICT (role, perm) DO NOTHING",
          [role, perm]
        );
      }
    })().catch((err) => {
      globalForEnsure.ceramEnsure = undefined;
      throw err;
    });
  }
  return globalForEnsure.ceramEnsure;
}

export async function query<T extends QueryResultRow = QueryResultRow>(
  text: string,
  params?: unknown[]
): Promise<T[]> {
  await ensureSchema();
  const res = await pool.query(text, params as never[]);
  return res.rows as T[];
}

export async function queryOne<T extends QueryResultRow = QueryResultRow>(
  text: string,
  params?: unknown[]
): Promise<T | null> {
  const rows = await query<T>(text, params);
  return rows.length > 0 ? rows[0] : null;
}

// معاملة ذرّية — يُنفَّذ الـ callback على عميل واحد ثم يُعاد للـ pool
export async function withTransaction<T>(
  fn: (tx: {
    query: <U extends QueryResultRow = QueryResultRow>(
      text: string,
      params?: unknown[]
    ) => Promise<U[]>;
  }) => Promise<T>
): Promise<T> {
  await ensureSchema();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const tx = {
      query: async <U extends QueryResultRow = QueryResultRow>(
        text: string,
        params?: unknown[]
      ) => {
        const res = await client.query(text, params as never[]);
        return res.rows as U[];
      },
    };
    const out = await fn(tx);
    await client.query("COMMIT");
    return out;
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch {
      /* تجاهل فشل التراجع */
    }
    throw err;
  } finally {
    client.release();
  }
}

export async function logAction(
  userId: number | null,
  action: string,
  detail?: string
): Promise<void> {
  try {
    await pool.query(
      "INSERT INTO web_log (user_id, action, detail) VALUES ($1, $2, $3)",
      [userId, action, detail?.slice(0, 500) ?? null]
    );
  } catch {
    /* السجل التدقيقي لا يعطّل العملية أبداً */
  }
}
