"use client";

// مساعدات العميل: استدعاء API + تنسيق عربي (أرقام لاتينية كما في الجزائر)

export interface ApiResponse extends Record<string, unknown> {
  ok: boolean;
  error?: string;
}

export async function api(path: string, opts?: RequestInit): Promise<ApiResponse> {
  try {
    const res = await fetch(path, {
      ...opts,
      headers: { "Content-Type": "application/json", ...(opts?.headers ?? {}) },
    });
    const data = (await res.json()) as ApiResponse;
    return data;
  } catch {
    return { ok: false, error: "تعذر الاتصال بالخادم — تحقق من الشبكة" };
  }
}

export function parseDate(s: string | null | undefined): Date | null {
  if (!s) return null;
  let t = s.trim().replace(" ", "T");
  if (/\+00$/.test(t)) t += ":00";
  const d = new Date(t);
  return isNaN(d.getTime()) ? null : d;
}

const NUM = new Intl.NumberFormat("ar-DZ-u-nu-latn");
const DATE_SHORT = new Intl.DateTimeFormat("ar-DZ-u-nu-latn", {
  day: "numeric",
  month: "short",
});
const DATETIME = new Intl.DateTimeFormat("ar-DZ-u-nu-latn", {
  day: "numeric",
  month: "short",
  hour: "2-digit",
  minute: "2-digit",
});

export function fmtNum(n: number | string | null | undefined): string {
  const v = typeof n === "string" ? Number(n) : n;
  return v === null || v === undefined || !Number.isFinite(v) ? "—" : NUM.format(v);
}

export function fmtMoney(n: number | string | null | undefined): string {
  const v = typeof n === "string" ? Number(n) : n;
  return v === null || v === undefined || !Number.isFinite(v) ? "—" : `${NUM.format(v)} د.ج`;
}

export function fmtDate(s: string | null | undefined): string {
  const d = parseDate(s);
  return d ? DATE_SHORT.format(d) : "—";
}

export function fmtDateTime(s: string | null | undefined): string {
  const d = parseDate(s);
  return d ? DATETIME.format(d) : "—";
}

export function daysSince(s: string | null | undefined): number | null {
  const d = parseDate(s);
  if (!d) return null;
  return Math.floor((Date.now() - d.getTime()) / 86_400_000);
}
