// ═══════════════════════════════════════════════════════════════
//  نموذج الفئات والصلاحيات — مطابق حرفياً للبوت (v23):
//  ROLE_* / PERM_* / ROLE_LABELS / PERM_LABELS / ROLE_PERM_CATALOG
//  + منطق is_admin وحسابات الحماية عبر ADMIN_IDS/OWNER_IDS.
// ═══════════════════════════════════════════════════════════════

export const ROLES = [
  "admin",
  "manager",
  "stock",
  "seller",
  "external",
  "customer",
  "pending",
] as const;
export type Role = (typeof ROLES)[number];

export const ROLE_LABELS: Record<Role, string> = {
  admin: "👑 مدير النظام",
  manager: "🧑‍💼 مدير البوت",
  stock: "📦 عامل مخزون",
  seller: "🛍 بائع",
  external: "🌍 بائع خارجي",
  customer: "👤 عميل",
  pending: "⏳ قيد المراجعة",
};

export const PERMS = [
  "search",
  "add_qty",
  "remove",
  "invoice",
  "supply_order",
  "my_orders",
  "movements",
  "add_product",
  "edit_product",
  "low_stock",
  "pending",
] as const;
export type Perm = (typeof PERMS)[number];

export const PERM_LABELS: Record<Perm, string> = {
  search: "🔍 البحث",
  add_qty: "➕ إضافة كمية",
  remove: "➖ إخراج كمية",
  invoice: "🧾 إنشاء فاتورة",
  supply_order: "📦 طلب توريد جديد",
  my_orders: "📋 طلباتي",
  movements: "📋 الحركة",
  add_product: "📦 إضافة سلعة",
  edit_product: "✏️ تعديل سلعة",
  low_stock: "📊 المخزون المنخفض",
  pending: "🔴 الطلبات المعلقة",
};

// الصلاحيات القابلة للإدارة لكل فئة (= الافتراضي المفعّل عند أول تشغيل)
// مطابق لـ ROLE_PERM_CATALOG في البوت: seller / stock / external فقط
export const EDITABLE_PERM_ROLES = ["seller", "stock", "external"] as const;
export type EditablePermRole = (typeof EDITABLE_PERM_ROLES)[number];

export const EDITABLE_PERM_ROLES_LIST: string[] = ["seller", "stock", "external"];

// فئة العميل: السلوك القديم كما هو — خارج نظام الصلاحيات في البوت
// (أزرارها الكلاسيكية: إضافة، إخراج، الحركة، طلب توريد، طلباتي)
export const CUSTOMER_CLASSIC_PERMS: Perm[] = [
  "add_qty",
  "remove",
  "movements",
  "supply_order",
  "my_orders",
];

export function isAdminRole(role: string): boolean {
  return role === "admin" || role === "manager";
}

// ── حسابات الحماية من متغيرات البيئة (كما في البوت) ──
export function envIdList(name: "ADMIN_IDS" | "OWNER_IDS"): number[] {
  const raw = process.env[name] || "";
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter((s) => /^\d+$/.test(s))
    .map(Number);
}

export function isProtectedTelegramId(telegramId: number): boolean {
  return (
    envIdList("ADMIN_IDS").includes(telegramId) ||
    envIdList("OWNER_IDS").includes(telegramId)
  );
}

// هل هذا المستخدم إدارة؟ (فئة + قوائم البيئة، مطابق للبوت)
export function userIsAdmin(user: {
  role: string;
  telegram_id: number;
}): boolean {
  if (isAdminRole(user.role)) return true;
  return isProtectedTelegramId(user.telegram_id);
}

// الإدارة ترى كل الصلاحيات دائماً (مطابق لبوت v23)
export function adminPerms(): Perm[] {
  return [...PERMS];
}
