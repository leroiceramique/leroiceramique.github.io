// ═══════════════════════════════════════════════════════════════
//  المصادقة وجلسات الويب — كلمات مرور scrypt + جلسات في القاعدة
//  مع كوكيز httpOnly. مطابق لروح البوت:
//   • المطرود (active=FALSE) يُرفض برسالة KICK_NOTICE نفسها
//   • حسابات ADMIN_IDS/OWNER_IDS تمرّ دائماً (استثناء البوابة)
//   • فئة pending ترى «قيد المراجعة»
// ═══════════════════════════════════════════════════════════════
import { randomBytes, scryptSync, timingSafeEqual, createHash } from "node:crypto";
import { cookies } from "next/headers";
import { query, queryOne, logAction } from "./db";
import {
  PERMS,
  adminPerms,
  userIsAdmin,
  CUSTOMER_CLASSIC_PERMS,
  type Perm,
} from "./perm";

export const SESSION_COOKIE = "ceramweb_session";
const SESSION_DAYS = 30;

export interface SessionUser {
  id: number;
  telegram_id: number;
  username: string | null;
  first_name: string | null;
  role: string;
  active: boolean;
  created_at: string;
}

// ── كلمات المرور (نفس صيغة خدمة الزرع) ──
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(":");
    if (!salt || !hash) return false;
    const candidate = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

// ── الجلسات ──
export function tokenHash(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

export async function createSession(userId: number): Promise<string> {
  const token = randomBytes(32).toString("hex"); // يُخزَّن هاشاً في القاعدة
  const th = tokenHash(token);
  await query(
    `INSERT INTO web_sessions (token, user_id, expires_at)
     VALUES ($1, $2, NOW() + INTERVAL '${SESSION_DAYS} days')`,
    [th, userId]
  );
  // تنظيف فرصي للجلسات المنتهية
  await query("DELETE FROM web_sessions WHERE expires_at < NOW()").catch(() => {});
  return token;
}

export async function destroySession(token: string): Promise<void> {
  await query("DELETE FROM web_sessions WHERE token = $1", [tokenHash(token)]);
}

export async function destroyUserSessions(userId: number): Promise<void> {
  await query("DELETE FROM web_sessions WHERE user_id = $1", [userId]);
}

export async function setSessionCookie(token: string): Promise<void> {
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_DAYS * 24 * 3600,
    path: "/",
  });
}

export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.set(SESSION_COOKIE, "", { httpOnly: true, maxAge: 0, path: "/" });
}

// ── المستخدم الحالي من الكوكي (أو null) ──
export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    return await getSessionUserByToken(token);
  } catch {
    return null;
  }
}

export async function getSessionUserByToken(
  token: string
): Promise<SessionUser | null> {
  const row = await queryOne<SessionUser>(
    `SELECT u.id, u.telegram_id::float8 AS "telegram_id", u.username, u.first_name,
            u.role, u.active, u.created_at::text
     FROM web_sessions s
     JOIN users u ON u.id = s.user_id
     WHERE s.token = $1 AND s.expires_at > NOW()`,
    [tokenHash(token)]
  );
  return row ?? null;
}

// ── تسجيل الدخول ──
export const KICK_NOTICE =
  "⛔ تم إيقاف حسابك من قبل الإدارة.\nللاستفسار تواصل مع إدارة البوت.";

export type LoginResult =
  | { ok: true; user: SessionUser; token: string }
  | { ok: false; reason: "bad_credentials" | "kicked" | "no_password" };

export async function login(
  username: string,
  password: string
): Promise<LoginResult> {
  const norm = username.replace(/@/g, "").trim().toLowerCase();
  const row = await queryOne<{
    id: number;
    telegram_id: string;
    username: string | null;
    first_name: string | null;
    role: string;
    active: boolean;
    created_at: string;
    password_hash: string | null;
  }>(
    `SELECT u.id, u.telegram_id::text, u.username, u.first_name, u.role,
            u.active, u.created_at::text, w.password_hash
     FROM users u
     LEFT JOIN web_auth w ON w.user_id = u.id
     WHERE LOWER(u.username) = $1
     LIMIT 1`,
    [norm]
  );
  if (!row || !row.password_hash) return { ok: false, reason: "bad_credentials" };
  if (!verifyPassword(password, row.password_hash))
    return { ok: false, reason: "bad_credentials" };

  const user: SessionUser = {
    id: row.id,
    telegram_id: Number(row.telegram_id),
    username: row.username,
    first_name: row.first_name,
    role: row.role,
    active: row.active,
    created_at: row.created_at,
  };

  // استثناء الإدارة المصرّح بها من البيئة (مطابق لبوب kicked_gate)
  const envProtected = userIsAdmin({
    role: user.role,
    telegram_id: user.telegram_id,
  }) && (
    process.env.ADMIN_IDS?.split(",").map(Number).includes(user.telegram_id) ||
    process.env.OWNER_IDS?.split(",").map(Number).includes(user.telegram_id)
  );

  if (!user.active && !envProtected) {
    await logAction(user.id, "login_blocked_kicked", `@${user.username}`);
    return { ok: false, reason: "kicked" };
  }

  const token = await createSession(user.id);
  await logAction(user.id, "login", `@${user.username}`);
  return { ok: true, user, token };
}

// ── الصلاحيات الفعلية (قاعدة + إدارة) — مطابق لـ get_role_perms في البوت ──
export async function effectivePerms(user: SessionUser): Promise<Perm[]> {
  if (userIsAdmin(user)) return adminPerms();

  // فئة العميل: السلوك القديم كما هو — خارج نظام الصلاحيات (كالبوت)
  if (user.role === "customer") return [...CUSTOMER_CLASSIC_PERMS];
  // قيد المراجعة: لا شيء حتى تُفعّل الإدارة الحساب
  if (user.role === "pending") return [];

  // فئات النظام (seller/stock/external): قراءة من القاعدة مع سقوط آمن
  const rows = await query<{ perm: Perm }>(
    "SELECT perm FROM role_permissions WHERE role = $1 AND enabled = TRUE",
    [user.role]
  );
  const valid = new Set<string>(PERMS);
  if (rows.length > 0) return rows.map((r) => r.perm).filter((p) => valid.has(p));
  // لا صفوف → الافتراضي الآمن = ROLE_PERM_CATALOG
  return (ROLE_PERM_CATALOG as Record<string, Perm[]>)[user.role] ?? [];
}

// نسخة مطابقة لـ ROLE_PERM_CATALOG في البوت (للسقوط الآمن)
const ROLE_PERM_CATALOG = {
  seller: ["search", "add_qty", "remove", "invoice", "supply_order", "my_orders", "movements"],
  stock: ["add_qty", "add_product", "remove", "edit_product", "movements", "low_stock", "pending"],
  external: ["search"],
} as const;

export function hasPerm(perms: Perm[], perm: Perm): boolean {
  return perms.includes(perm);
}

// ── حرس API: يعيد المستخدم أو يرمي استجابة ──
export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new ApiError("يجب تسجيل الدخول أولاً", 401);
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireUser();
  if (!userIsAdmin(user)) throw new ApiError("هذه العملية للإدارة فقط", 403);
  return user;
}

export async function requirePerm(perm: Perm): Promise<SessionUser> {
  const user = await requireUser();
  const perms = await effectivePerms(user);
  if (!perms.includes(perm))
    throw new ApiError("لا تملك صلاحية هذه العملية", 403);
  return user;
}
