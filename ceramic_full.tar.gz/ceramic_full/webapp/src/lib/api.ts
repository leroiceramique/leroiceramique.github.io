// مساعدات مشتركة لمسارات API
import { NextResponse } from "next/server";
import { ApiError } from "./auth";

export function ok(data: Record<string, unknown> = {}) {
  return NextResponse.json({ ok: true, ...data });
}

export function fail(err: unknown) {
  if (err instanceof ApiError) {
    return NextResponse.json({ ok: false, error: err.message }, { status: err.status });
  }
  console.error("[api]", err);
  const msg = err instanceof Error ? err.message : "خطأ غير متوقع";
  if (/duplicate key/i.test(msg))
    return NextResponse.json(
      { ok: false, error: "قيمة مكررة — تحقق من اسم المستخدم أو المعرّف" },
      { status: 409 }
    );
  if (/violates foreign key/i.test(msg))
    return NextResponse.json(
      { ok: false, error: "لا يمكن تنفيذ العملية — توجد سجلات مرتبطة" },
      { status: 409 }
    );
  return NextResponse.json({ ok: false, error: msg }, { status: 500 });
}

export async function readBody<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    throw new ApiError("صيغة الطلب غير صالحة", 400);
  }
}

export function toInt(v: unknown, label = "القيمة"): number {
  const n = Number(v);
  if (!Number.isFinite(n) || !Number.isInteger(n))
    throw new ApiError(`${label} يجب أن يكون رقماً صحيحاً`, 400);
  return n;
}

export function toPosInt(v: unknown, label = "الكمية"): number {
  const n = toInt(v, label);
  if (n <= 0) throw new ApiError(`${label} يجب أن تكون أكبر من صفر`, 400);
  return n;
}

export function toNum(v: unknown, label = "القيمة"): number {
  const n = Number(v);
  if (!Number.isFinite(n)) throw new ApiError(`${label} يجب أن يكون رقماً`, 400);
  return n;
}

export function requireStr(v: unknown, label: string, max = 500): string {
  if (typeof v !== "string" || !v.trim())
    throw new ApiError(`${label} مطلوب`, 400);
  const s = v.trim();
  if (s.length > max) throw new ApiError(`${label} طويل جداً (الحد ${max})`, 400);
  return s;
}
