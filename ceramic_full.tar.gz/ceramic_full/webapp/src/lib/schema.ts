// ═══════════════════════════════════════════════════════════════
//  المخطط الكامل — نسخة مطابقة لمخطط البوت (bot.py SCHEMA_SQL v23)
//  + جداول الويب الإضافية. كل العبارات idempotent (IF NOT EXISTS)
//  فتنفَّذ بأمان على قاعدة بيانات البوت الموجودة عند النشر.
//  المصدر الوحيد لهذا النص: يستورده تطبيق الويب وخدمة PGlite معاً.
// ═══════════════════════════════════════════════════════════════

export const ENSURE_SQL = `
CREATE TABLE IF NOT EXISTS users (
    id          SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    username    VARCHAR(255),
    first_name  VARCHAR(255),
    role        VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (role IN ('admin', 'manager', 'stock', 'seller', 'external', 'customer', 'pending')),
    requested_role VARCHAR(20) DEFAULT NULL,
    active      BOOLEAN NOT NULL DEFAULT TRUE,
    can_extract       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS products (
    id             SERIAL PRIMARY KEY,
    name           VARCHAR(500) NOT NULL,
    quantity       INTEGER NOT NULL DEFAULT 0,
    location       VARCHAR(255) DEFAULT '',
    minimum_stock  INTEGER NOT NULL DEFAULT 5,
    selling_price  NUMERIC(12,2) NOT NULL DEFAULT 0,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS transactions (
    id         SERIAL PRIMARY KEY,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    type       VARCHAR(10) NOT NULL CHECK (type IN ('add', 'remove', 'reconcile')),
    quantity   INTEGER NOT NULL,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    date       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    reason     VARCHAR(200)
);

CREATE INDEX IF NOT EXISTS idx_products_name ON products (name);
CREATE INDEX IF NOT EXISTS idx_transactions_product ON transactions (product_id);
CREATE INDEX IF NOT EXISTS idx_transactions_date ON transactions (date);

CREATE TABLE IF NOT EXISTS extraction_requests (
    id            SERIAL PRIMARY KEY,
    product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity      INTEGER NOT NULL,
    requester_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    status        VARCHAR(10) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    processed_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_extraction_requests_status ON extraction_requests (status);
CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users (telegram_id);

CREATE TABLE IF NOT EXISTS incoming_orders (
    id             SERIAL PRIMARY KEY,
    requester_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    product_name   VARCHAR(500) NOT NULL,
    quantity       INTEGER NOT NULL DEFAULT 1,
    status         VARCHAR(12) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'received', 'completed')),
    photo_file_id  TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at   TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_incoming_orders_status ON incoming_orders (status);

CREATE TABLE IF NOT EXISTS bot_updates (
    id          SERIAL PRIMARY KEY,
    description TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bot_settings (
    key         VARCHAR(100) PRIMARY KEY,
    value       TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role     VARCHAR(20) NOT NULL,
    perm     VARCHAR(60) NOT NULL,
    enabled  BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (role, perm)
);

CREATE TABLE IF NOT EXISTS invoices (
    id              SERIAL PRIMARY KEY,
    customer_name   VARCHAR(500) NOT NULL,
    worker_id       INTEGER REFERENCES users(id) ON DELETE SET NULL,
    admin_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    total_amount    NUMERIC(12,2) NOT NULL DEFAULT 0,
    status          VARCHAR(15) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','approved','cancelled')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_at     TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS invoice_items (
    id              SERIAL PRIMARY KEY,
    invoice_id      INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    product_id      INTEGER REFERENCES products(id) ON DELETE SET NULL,
    product_name    VARCHAR(500) NOT NULL,
    quantity        INTEGER NOT NULL,
    unit_price      NUMERIC(12,2) NOT NULL DEFAULT 0,
    subtotal        NUMERIC(12,2) NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_invoices_status ON invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoice_items_invoice ON invoice_items(invoice_id);

CREATE TABLE IF NOT EXISTS pending_deliveries (
    id            SERIAL PRIMARY KEY,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    product_id    INTEGER REFERENCES products(id) ON DELETE SET NULL,
    pending_qty   INTEGER NOT NULL DEFAULT 0,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    fulfilled_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pending_deliveries_product ON pending_deliveries(product_id);
CREATE INDEX IF NOT EXISTS idx_pending_deliveries_user ON pending_deliveries(user_id);
CREATE INDEX IF NOT EXISTS idx_pending_deliveries_pending ON pending_deliveries(product_id) WHERE pending_qty > 0;

-- v21: صيانة الرافعة الشوكية — دورة زيت المحرك
CREATE TABLE IF NOT EXISTS oil_status (
    id                   INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
    baseline_hours       NUMERIC(10,1) NOT NULL DEFAULT 0,
    last_change_at       TIMESTAMPTZ,
    current_hours        NUMERIC(10,1),
    current_hours_at     TIMESTAMPTZ,
    confirm_worker_id    BIGINT,
    confirm_requested_at TIMESTAMPTZ,
    confirm_confirmed    BOOLEAN NOT NULL DEFAULT FALSE,
    confirm_confirmed_at TIMESTAMPTZ,
    weekly_remind_date   DATE,
    predict_sent_at      TIMESTAMPTZ,
    notified_200_date    DATE,
    notified_250_at      TIMESTAMPTZ,
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS oil_readings (
    id       SERIAL PRIMARY KEY,
    reading  NUMERIC(10,1) NOT NULL,
    read_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    by_name  VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS oil_log (
    id               SERIAL PRIMARY KEY,
    changed_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    hours_at_change  NUMERIC(10,1),
    recorded_by_name VARCHAR(255),
    note             VARCHAR(500)
);

CREATE INDEX IF NOT EXISTS idx_oil_readings_read_at ON oil_readings (read_at);
CREATE INDEX IF NOT EXISTS idx_oil_log_changed_at ON oil_log (changed_at);

-- ═══════════════════════════════════════════════════════════
--  جداول الويب (PWA) — إضافات خاصة بواجهة الويب فقط، البوت
--  لا يتعامل معها إطلاقاً.
-- ═══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS web_auth (
    user_id       INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    password_hash TEXT NOT NULL,
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS web_sessions (
    token      VARCHAR(64) PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_web_sessions_user ON web_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_web_sessions_expires ON web_sessions(expires_at);

CREATE TABLE IF NOT EXISTS web_log (
    id         SERIAL PRIMARY KEY,
    user_id    INTEGER,
    action     VARCHAR(60) NOT NULL,
    detail     VARCHAR(500),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_web_log_created ON web_log (created_at);
`;

// الصلاحيات الافتراضية — مطابقة لـ ROLE_PERM_CATALOG في البوت
export const DEFAULT_PERMS: Array<[string, string]> = [
  ["seller", "search"],
  ["seller", "add_qty"],
  ["seller", "remove"],
  ["seller", "invoice"],
  ["seller", "supply_order"],
  ["seller", "my_orders"],
  ["seller", "movements"],
  ["stock", "add_qty"],
  ["stock", "add_product"],
  ["stock", "remove"],
  ["stock", "edit_product"],
  ["stock", "movements"],
  ["stock", "low_stock"],
  ["stock", "pending"],
  ["external", "search"],
];
