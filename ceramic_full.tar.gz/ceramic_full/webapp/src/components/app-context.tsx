"use client";

import { createContext, useContext } from "react";
import type { Perm } from "@/lib/perm";

export interface MeUser {
  id: number;
  telegram_id: number;
  username: string | null;
  first_name: string | null;
  role: string;
  active: boolean;
  created_at: string;
}

export interface MeState {
  user: MeUser;
  perms: Perm[];
  is_admin: boolean;
  hide_qty: boolean;
}

export interface AppCtxValue {
  me: MeState;
  refreshMe: () => Promise<void>;
  tab: string;
  setTab: (t: string) => void;
  installReady: boolean;
  promptInstall: () => void;
}

export const AppCtx = createContext<AppCtxValue | null>(null);

export function useApp(): AppCtxValue {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("AppCtx مفقود");
  return ctx;
}

export function hasPerm(perms: Perm[], p: Perm): boolean {
  return perms.includes(p);
}
