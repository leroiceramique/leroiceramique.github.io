"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "@/lib/client";
import { AppCtx, type MeState } from "@/components/app-context";
import { LoginView } from "@/components/views/login";
import { DashboardView } from "@/components/views/dashboard";
import { InventoryView } from "@/components/views/inventory";
import { MovementsView } from "@/components/views/movements";
import { OrdersView } from "@/components/views/orders";
import { InvoicesView } from "@/components/views/invoices";
import { UsersView } from "@/components/views/users";
import { PermsView } from "@/components/views/perms";
import { OilView } from "@/components/views/oil";
import { ProfileView } from "@/components/views/profile";
import { RoleBadge } from "@/components/ui-kit";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import type { Perm } from "@/lib/perm";

interface NavItem {
  key: string;
  label: string;
  icon: string;
  visible: boolean;
}

interface BipEvent extends Event {
  prompt: () => Promise<void>;
}

export function AppRoot() {
  const [me, setMe] = useState<MeState | null>(null);
  const [loadingMe, setLoadingMe] = useState(true);
  const [tab, setTab] = useState("home");
  const [moreOpen, setMoreOpen] = useState(false);
  const [installEvt, setInstallEvt] = useState<BipEvent | null>(null);

  const refreshMe = useCallback(async () => {
    const res = await api("/api/me");
    if (res.ok && res.user) {
      setMe({ user: res.user as MeState["user"], perms: (res.perms as Perm[]) ?? [], is_admin: !!res.is_admin, hide_qty: !!res.hide_qty });
    } else {
      setMe(null);
    }
    setLoadingMe(false);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    refreshMe();
  }, [refreshMe]);

  useEffect(() => {
    function onBip(e: Event) {
      e.preventDefault();
      setInstallEvt(e as BipEvent);
    }
    window.addEventListener("beforeinstallprompt", onBip);
    return () => window.removeEventListener("beforeinstallprompt", onBip);
  }, []);

  const navItems: NavItem[] = useMemo(() => {
    if (!me) return [];
    const p = me.perms;
    const has = (x: Perm) => p.includes(x) || me.is_admin;
    return [
      { key: "home", label: "الرئيسية", icon: "🏠", visible: true },
      {
        key: "inventory", label: "المخزون", icon: "📦",
        visible: has("search") || has("add_product") || has("add_qty") || has("remove") || has("edit_product") || has("low_stock") || me.hide_qty,
      },
      { key: "movements", label: "الحركة", icon: "📋", visible: has("movements") },
      { key: "orders", label: "التوريد", icon: "🚚", visible: has("supply_order") || has("my_orders") || has("pending") },
      { key: "invoices", label: "الفواتير", icon: "🧾", visible: has("invoice") },
      { key: "oil", label: "الزيت", icon: "🛠️", visible: me.is_admin || me.user.role === "stock" },
      { key: "users", label: "المستخدمون", icon: "⚙️", visible: me.is_admin },
      { key: "perms", label: "الصلاحيات", icon: "🔐", visible: me.is_admin },
      { key: "profile", label: "ملفي", icon: "👤", visible: true },
    ];
  }, [me]);

  const visible = navItems.filter((n) => n.visible);
  const primary = visible.slice(0, 4);
  const overflow = visible.slice(4);

  const promptInstall = useCallback(() => {
    if (installEvt) {
      installEvt.prompt();
      setInstallEvt(null);
    }
  }, [installEvt]);

  const ctx = useMemo(
    () => ({
      me: me as MeState,
      refreshMe,
      tab,
      setTab: (t: string) => {
        setTab(t);
        setMoreOpen(false);
        window.scrollTo({ top: 0 });
      },
      installReady: installEvt !== null,
      promptInstall,
    }),
    [me, refreshMe, tab, installEvt, promptInstall]
  );

  if (loadingMe) {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center gap-3">
        <img src="/icons/icon-192.png" alt="" className="w-16 h-16 rounded-2xl animate-pulse" />
        <p className="text-sm text-muted-foreground">جارٍ الاتصال بمخزون السيراميك…</p>
      </div>
    );
  }

  if (!me) return <LoginView onLoggedIn={() => refreshMe()} />;

  const activeNav = navItems.find((n) => n.key === tab);

  function renderView() {
    switch (tab) {
      case "home":
        return <DashboardView />;
      case "inventory":
        return <InventoryView onMutated={refreshMe} />;
      case "movements":
        return <MovementsView />;
      case "orders":
        return <OrdersView onMutated={refreshMe} />;
      case "invoices":
        return <InvoicesView onMutated={refreshMe} />;
      case "users":
        return <UsersView />;
      case "perms":
        return <PermsView />;
      case "oil":
        return <OilView />;
      default:
        return <ProfileView />;
    }
  }

  return (
    <AppCtx.Provider value={ctx}>
      <div className="min-h-dvh flex flex-col lg:flex-row-reverse">
        {/* الشريط الجانبي — سطح المكتب */}
        <aside className="hidden lg:flex flex-col w-64 shrink-0 border-s bg-card sticky top-0 h-dvh p-4 gap-1">
          <div className="flex items-center gap-2.5 px-2 pb-4 pt-2">
            <img src="/icons/icon-192.png" alt="" className="w-10 h-10 rounded-xl" />
            <div>
              <p className="font-extrabold text-sm leading-tight">مخزون السيراميك</p>
              <p className="text-[10px] text-muted-foreground">متزامن مع بوت تلغرام</p>
            </div>
          </div>
          {visible.map((n) => (
            <button
              key={n.key}
              onClick={() => ctx.setTab(n.key)}
              className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors text-right ${
                tab === n.key
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "hover:bg-accent text-foreground"
              }`}
            >
              <span className="text-base">{n.icon}</span>
              {n.label}
            </button>
          ))}
          <div className="mt-auto rounded-xl bg-secondary/60 p-3">
            <p className="text-xs font-bold truncate">{me.user.first_name ?? "—"}</p>
            <div className="mt-1.5"><RoleBadge role={me.user.role} /></div>
          </div>
        </aside>

        <div className="flex-1 flex flex-col min-w-0">
          {/* الترويسة */}
          <header className="sticky top-0 z-20 lg:hidden bg-primary text-primary-foreground shadow-md" style={{ paddingTop: "env(safe-area-inset-top)" }}>
            <div className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-lg">{activeNav?.icon ?? "🏠"}</span>
                <h1 className="font-extrabold truncate">{activeNav?.label ?? "مخزون السيراميك"}</h1>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-[11px] opacity-90 truncate max-w-24">{me.user.first_name ?? "—"}</span>
              </div>
            </div>
          </header>

          {/* المحتوى */}
          <main className="flex-1 px-4 py-4 pb-28 lg:pb-8 max-w-3xl w-full mx-auto">{renderView()}</main>

          {/* تذييل سفل — يلتصق أسفل الشاشة */}
          <footer className="hidden lg:block mt-auto py-4 text-center text-[11px] text-muted-foreground">
            مخزون السيراميك — تطبيق ويب متزامن مع بوت تلغرام · يعمل على نفس قاعدة البيانات
          </footer>

          {/* شريط التنقل السفلي — موبايل */}
          <nav
            className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-card border-t shadow-[0_-2px_10px_rgba(0,0,0,0.05)]"
            style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
          >
            <div className="grid grid-cols-5 h-16">
              {primary.map((n) => (
                <button
                  key={n.key}
                  onClick={() => ctx.setTab(n.key)}
                  className={`flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors ${
                    tab === n.key ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  <span className="text-xl leading-none">{n.icon}</span>
                  {n.label}
                </button>
              ))}
              {overflow.length > 0 ? (
                <Sheet open={moreOpen} onOpenChange={setMoreOpen}>
                  <SheetTrigger asChild>
                    <button
                      className={`flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium ${
                        overflow.some((n) => n.key === tab) ? "text-primary" : "text-muted-foreground"
                      }`}
                    >
                      <span className="text-xl leading-none">•••</span>
                      المزيد
                    </button>
                  </SheetTrigger>
                  <SheetContent side="bottom" className="rounded-t-3xl pb-8">
                    <SheetHeader className="text-right">
                      <SheetTitle>المزيد من الأقسام</SheetTitle>
                    </SheetHeader>
                    <div className="grid grid-cols-4 gap-3 pt-2">
                      {overflow.map((n) => (
                        <button
                          key={n.key}
                          onClick={() => ctx.setTab(n.key)}
                          className={`flex flex-col items-center gap-1.5 rounded-2xl border p-3 text-xs font-medium ${
                            tab === n.key ? "border-primary bg-primary/10 text-primary" : "bg-card"
                          }`}
                        >
                          <span className="text-2xl">{n.icon}</span>
                          {n.label}
                        </button>
                      ))}
                    </div>
                  </SheetContent>
                </Sheet>
              ) : null}
            </div>
          </nav>
        </div>
      </div>
    </AppCtx.Provider>
  );
}
