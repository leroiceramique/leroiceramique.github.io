"use client";

import { useCallback, useEffect, useState } from "react";
import { api, fmtNum, fmtMoney, fmtDateTime } from "@/lib/client";
import { useApp, hasPerm } from "@/components/app-context";
import { SectionTitle, EmptyState, LoadingBlock, ErrorNote, INVOICE_STATUS_META } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface InvoiceItem {
  invoice_id: number;
  product_id: number | null;
  product_name: string;
  quantity: number;
  unit_price: string;
  subtotal: string;
}
interface Invoice {
  id: number;
  customer_name: string;
  total_amount: string;
  status: string;
  created_at: string;
  approved_at: string | null;
  worker_name: string | null;
  admin_name: string | null;
  items: InvoiceItem[];
}
interface ProductOpt { id: number; name: string; selling_price?: string; quantity?: number }

export function InvoicesView({ onMutated }: { onMutated?: () => void }) {
  const { me } = useApp();
  const isAdmin = me.is_admin;
  const canInvoice = hasPerm(me.perms, "invoice");

  const [mode, setMode] = useState<"list" | "new">("list");
  const [invoices, setInvoices] = useState<Invoice[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  // — نموذج فاتورة جديدة —
  const [products, setProducts] = useState<ProductOpt[]>([]);
  const [customer, setCustomer] = useState("");
  const [picked, setPicked] = useState<string>("");
  const [qty, setQty] = useState("1");
  const [price, setPrice] = useState("");
  const [cart, setCart] = useState<Array<{ product_id: number; name: string; qty: number; price: number }>>([]);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const [confirmInvoice, setConfirmInvoice] = useState<Invoice | null>(null);
  const [confirmBusy, setConfirmBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    const res = await api("/api/invoices");
    if (!res.ok) { setError(res.error ?? "فشل التحميل"); setInvoices([]); return; }
    setInvoices((res.invoices as Invoice[]) ?? []);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (mode === "list") load();
    else {
      api("/api/products?sort=name").then((res) => {
        if (res.ok) setProducts(((res.products as ProductOpt[]) ?? []).filter((p) => !me.hide_qty || p.available));
      });
    }
  }, [mode, load, me.hide_qty]);

  if (!canInvoice && !isAdmin)
    return (
      <EmptyState icon="🔒" title="لا تملك صلاحية الفواتير"
        sub="صلاحية «إنشاء فاتورة» تمنحها الإدارة" />
    );

  function pickProduct(v: string) {
    setPicked(v);
    const p = products.find((x) => String(x.id) === v);
    if (p) setPrice(String(Number(p.selling_price ?? 0)));
  }

  function addToCart() {
    const p = products.find((x) => String(x.id) === picked);
    const n = Number(qty);
    const pr = Number(price);
    if (!p) { setFormError("اختر سلعة من القائمة"); return; }
    if (!Number.isInteger(n) || n <= 0) { setFormError("الكمية يجب أن تكون رقماً صحيحاً أكبر من صفر"); return; }
    if (!Number.isFinite(pr) || pr < 0) { setFormError("أدخل سعراً صحيحاً"); return; }
    setFormError(null);
    setCart((c) => [...c, { product_id: p.id, name: p.name, qty: n, price: pr }]);
    setPicked("");
    setQty("1");
    setPrice("");
  }

  async function submitInvoice() {
    if (!customer.trim()) { setFormError("أدخل اسم الزبون"); return; }
    if (cart.length === 0) { setFormError("السلة فارغة — أضف سلعة واحدة على الأقل"); return; }
    setBusy(true);
    setFormError(null);
    const res = await api("/api/invoices", {
      method: "POST",
      body: JSON.stringify({
        customer_name: customer,
        items: cart.map((c) => ({ product_id: c.product_id, quantity: c.qty, unit_price: c.price })),
      }),
    });
    setBusy(false);
    if (!res.ok) { setFormError(res.error ?? "فشل إنشاء الفاتورة"); return; }
    setCart([]);
    setCustomer("");
    setMode("list");
    onMutated?.();
  }

  async function setStatus(inv: Invoice, status: "approved" | "cancelled") {
    setConfirmBusy(true);
    const res = await api(`/api/invoices/${inv.id}`, { method: "PATCH", body: JSON.stringify({ status }) });
    setConfirmBusy(false);
    setConfirmInvoice(null);
    if (!res.ok) { setError(res.error ?? "فشل تحديث الفاتورة"); return; }
    load();
    onMutated?.();
  }

  const cartTotal = cart.reduce((s, c) => s + c.qty * c.price, 0);

  return (
    <div className="space-y-4">
      <SectionTitle
        title="🧾 الفواتير"
        action={
          <div className="flex gap-2">
            <Button size="sm" variant={mode === "list" ? "default" : "outline"} className="rounded-full text-xs h-8" onClick={() => setMode("list")}>
              القائمة
            </Button>
            <Button size="sm" variant={mode === "new" ? "default" : "outline"} className="rounded-full text-xs h-8" onClick={() => setMode("new")}>
              ＋ فاتورة
            </Button>
          </div>
        }
      />

      {error ? <ErrorNote msg={error} /> : null}

      {mode === "list" ? (
        invoices === null ? (
          <LoadingBlock rows={4} />
        ) : invoices.length === 0 ? (
          <EmptyState icon="🧾" title="لا فواتير بعد" sub="أنشئ أول فاتورة بزر «＋ فاتورة»" />
        ) : (
          <div className="space-y-3">
            {invoices.map((inv) => {
              const st = INVOICE_STATUS_META[inv.status] ?? INVOICE_STATUS_META.draft;
              return (
                <div key={inv.id} className="rounded-xl border bg-card p-4 shadow-sm space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="font-bold">#{fmtNum(inv.id)} — {inv.customer_name}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {inv.worker_name ?? "—"} · {fmtDateTime(inv.created_at)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {inv.items.length} بند: {inv.items.map((i) => `${i.product_name} ×${i.quantity}`).join("، ")}
                      </p>
                    </div>
                    <div className="text-left shrink-0 space-y-1">
                      <div className="text-lg font-extrabold text-primary">{fmtMoney(inv.total_amount)}</div>
                      <Badge className={`text-[10px] ${st.cls}`}>{st.label}</Badge>
                    </div>
                  </div>
                  {isAdmin && inv.status === "draft" ? (
                    <div className="flex gap-2 pt-1">
                      <Button size="sm" className="h-8 text-xs rounded-full" onClick={() => setConfirmInvoice(inv)}>
                        ✅ اعتماد وخصم المخزون
                      </Button>
                      <Button size="sm" variant="outline" className="h-8 text-xs rounded-full text-destructive hover:text-destructive"
                        onClick={() => setStatus(inv, "cancelled")}>
                        ✖ إلغاء
                      </Button>
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        )
      ) : (
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="inv-customer">اسم الزبون / الجهة</Label>
            <Input id="inv-customer" value={customer} onChange={(e) => setCustomer(e.target.value)}
              placeholder="مثال: مؤسسة البناء الحديث" />
          </div>

          <div className="rounded-xl border bg-card p-4 space-y-3">
            <p className="text-sm font-bold">إضافة بند</p>
            <Select value={picked} onValueChange={pickProduct}>
              <SelectTrigger className="h-11">
                <SelectValue placeholder="اختر السلعة…" />
              </SelectTrigger>
              <SelectContent className="max-h-64">
                {products.map((p) => (
                  <SelectItem key={p.id} value={String(p.id)}>
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="inv-qty">الكمية</Label>
                <Input id="inv-qty" type="number" inputMode="numeric" dir="ltr" className="text-left" value={qty}
                  onChange={(e) => setQty(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="inv-price">سعر الوحدة (د.ج)</Label>
                <Input id="inv-price" type="number" inputMode="decimal" dir="ltr" className="text-left" value={price}
                  onChange={(e) => setPrice(e.target.value)} />
              </div>
            </div>
            <Button className="w-full" variant="secondary" onClick={addToCart}>
              ＋ إضافة إلى السلة
            </Button>
          </div>

          {cart.length > 0 ? (
            <div className="rounded-xl border bg-card divide-y overflow-hidden">
              {cart.map((c, i) => (
                <div key={i} className="flex items-center justify-between gap-2 px-4 py-2.5">
                  <div className="min-w-0">
                    <p className="text-sm font-bold truncate">{c.name}</p>
                    <p className="text-[11px] text-muted-foreground">
                      {fmtNum(c.qty)} × {fmtMoney(c.price)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm font-extrabold">{fmtMoney(c.qty * c.price)}</span>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-destructive"
                      onClick={() => setCart((arr) => arr.filter((_, j) => j !== i))}>
                      ✖
                    </Button>
                  </div>
                </div>
              ))}
              <div className="flex items-center justify-between px-4 py-3 bg-secondary/60">
                <span className="text-sm font-bold">الإجمالي</span>
                <span className="text-lg font-extrabold text-primary">{fmtMoney(cartTotal)}</span>
              </div>
            </div>
          ) : null}

          {formError ? <ErrorNote msg={formError} /> : null}
          <Button className="w-full h-12 text-base" disabled={busy} onClick={submitInvoice}>
            {busy ? "جارٍ الحفظ…" : "💾 حفظ الفاتورة (مسودة)"}
          </Button>
          <p className="text-[11px] text-muted-foreground text-center leading-relaxed">
            تُحفظ الفاتورة كمسودة، وعند اعتمادها من الإدارة تُخصم الكميات من المخزون تلقائياً.
          </p>
        </div>
      )}

      {/* تأكيد الاعتماد */}
      <AlertDialog open={confirmInvoice !== null} onOpenChange={(o) => !o && setConfirmInvoice(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>✅ اعتماد الفاتورة؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم خصم كميات البنود من المخزون وتسجيلها كحركة إخراج. ما يزيد عن المتوفر يُسجَّل تسليماً معلقاً.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction disabled={confirmBusy}
              onClick={(e) => { e.preventDefault(); if (confirmInvoice) setStatus(confirmInvoice, "approved"); }}>
              {confirmBusy ? "جارٍ الاعتماد…" : "اعتماد"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
