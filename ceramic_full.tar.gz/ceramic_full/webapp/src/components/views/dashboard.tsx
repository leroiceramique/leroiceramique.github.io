"use client";

import { useCallback, useEffect, useState } from "react";
import { api, fmtNum, fmtMoney, fmtDateTime } from "@/lib/client";
import { useApp } from "@/components/app-context";
import { StatCard, SectionTitle, LoadingBlock, TYPE_META } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface DashStats {
  totals?: { products: number; quantity: number; value: number };
  low_count?: number;
  my_pending_orders?: number;
  all_pending_orders?: number;
  recent_movements?: Array<{
    type: string;
    quantity: number;
    date: string;
    product_name: string;
    user_name: string | null;
  }>;
  month_invoices?: { total: number; count: number };
  draft_invoices?: number;
  oil?: { current: number; baseline: number; since_change: number };
}

export function DashboardView() {
  const { me, setTab } = useApp();
  const [stats, setStats] = useState<DashStats | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await api("/api/dashboard");
    setLoading(false);
    if (res.ok) setStats((res.stats as DashStats) ?? {});
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load]);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? "صباح الخير" : hour < 17 ? "مساء النور" : "مساء الخير";

  return (
    <div className="space-y-5">
      <div className="rounded-2xl bg-gradient-to-l from-primary to-primary/70 text-primary-foreground p-5 shadow-md">
        <p className="text-sm opacity-90">{greeting}،</p>
        <h1 className="text-xl font-extrabold mt-0.5">{me.user.first_name ?? me.user.username}</h1>
        <p className="text-xs opacity-80 mt-2 leading-relaxed">
          كل ما تراه هنا مباشرة من قاعدة بيانات المخزون — أي تغيير يظهر فوراً للبوت وأصحاب تلغرام.
        </p>
      </div>

      {loading ? (
        <LoadingBlock rows={4} />
      ) : (
        <>
          {stats?.totals ? (
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              <StatCard
                icon={<span>📦</span>}
                label="السلع"
                value={fmtNum(stats.totals.products)}
                hint="عدد الأصناف المسجلة"
                onClick={() => setTab("inventory")}
              />
              <StatCard
                icon={<span>🔢</span>}
                label="إجمالي الوحدات"
                value={fmtNum(stats.totals.quantity)}
                hint="كل الكميات بالمخازن"
                onClick={() => setTab("inventory")}
              />
              <StatCard
                icon={<span>💰</span>}
                label="قيمة المخزون"
                value={fmtMoney(stats.totals.value)}
                hint="كميات × أسعار البيع"
              />
              {stats.low_count !== undefined ? (
                <StatCard
                  icon={<span>⚠️</span>}
                  label="منخفض المخزون"
                  value={fmtNum(stats.low_count)}
                  hint="وصلت حد التنبيه"
                  tone={stats.low_count > 0 ? "warn" : "good"}
                  onClick={() => setTab("inventory")}
                />
              ) : null}
            </div>
          ) : null}

          {(stats?.all_pending_orders !== undefined || stats?.my_pending_orders !== undefined) && (
            <div className="grid grid-cols-2 gap-3">
              {stats.all_pending_orders !== undefined ? (
                <StatCard
                  icon={<span>🚚</span>}
                  label="طلبات توريد معلقة"
                  value={fmtNum(stats.all_pending_orders)}
                  hint="بانتظار المعالجة (الكل)"
                  tone={stats.all_pending_orders > 0 ? "warn" : "good"}
                  onClick={() => setTab("orders")}
                />
              ) : (
                <StatCard
                  icon={<span>🚚</span>}
                  label="طلباتي المعلقة"
                  value={fmtNum(stats.my_pending_orders ?? 0)}
                  tone={(stats.my_pending_orders ?? 0) > 0 ? "warn" : "good"}
                  onClick={() => setTab("orders")}
                />
              )}
              {stats.month_invoices ? (
                <StatCard
                  icon={<span>🧾</span>}
                  label="فواتير الشهر"
                  value={fmtMoney(stats.month_invoices.total)}
                  hint={`${fmtNum(stats.month_invoices.count)} فاتورة معتمدة`}
                  onClick={() => setTab("invoices")}
                />
              ) : null}
            </div>
          )}

          {stats?.oil ? (
            <Card className="border-primary/25">
              <CardContent className="p-4 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">🛠️</span>
                  <div>
                    <p className="text-sm font-bold">زيت الرافعة الشوكية</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      منذ آخر تغيير: <b>{fmtNum(stats.oil.since_change)}</b> ساعة عمل
                    </p>
                  </div>
                </div>
                <Button size="sm" variant="outline" onClick={() => setTab("oil")}>
                  التفاصيل
                </Button>
              </CardContent>
            </Card>
          ) : null}

          {stats?.recent_movements && stats.recent_movements.length > 0 ? (
            <div>
              <SectionTitle
                title="آخر الحركات"
                action={
                  <Button size="sm" variant="ghost" onClick={() => setTab("movements")}>
                    الكل ←
                  </Button>
                }
              />
              <div className="rounded-xl border bg-card divide-y overflow-hidden">
                {stats.recent_movements.map((m, i) => {
                  const meta = TYPE_META[m.type] ?? TYPE_META.add;
                  return (
                    <div key={i} className="flex items-center justify-between gap-2 px-4 py-2.5">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className={`text-sm font-bold ${meta.cls}`}>{meta.icon}</span>
                        <div className="min-w-0">
                          <p className="text-sm font-medium truncate">{m.product_name}</p>
                          <p className="text-[11px] text-muted-foreground">
                            {m.user_name ?? "—"} · {fmtDateTime(m.date)}
                          </p>
                        </div>
                      </div>
                      <span className={`text-sm font-extrabold shrink-0 ${meta.cls}`}>
                        {m.type === "remove" ? "−" : m.type === "add" ? "+" : "→"}
                        {fmtNum(Math.abs(m.quantity))}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
