"use client";

import { useCallback, useEffect, useState } from "react";
import { api, fmtNum, fmtDateTime } from "@/lib/client";
import { useApp, hasPerm } from "@/components/app-context";
import { SectionTitle, EmptyState, LoadingBlock, ErrorNote, TYPE_META } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";

interface Movement {
  id: number;
  type: string;
  quantity: number;
  date: string;
  reason: string | null;
  product_name: string;
  product_id: number;
  user_name: string | null;
  user_username: string | null;
}

export function MovementsView() {
  const { me } = useApp();
  const isAdmin = me.is_admin;
  const [type, setType] = useState<"all" | "add" | "remove" | "reconcile">("all");
  const [mine, setMine] = useState(false);
  const [rows, setRows] = useState<Movement[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const params = new URLSearchParams();
    if (type !== "all") params.set("type", type);
    if (mine) params.set("mine", "1");
    const res = await api(`/api/movements?${params.toString()}`);
    if (!res.ok) {
      setError(res.error ?? "فشل التحميل");
      setRows([]);
      return;
    }
    setRows((res.movements as Movement[]) ?? []);
  }, [type, mine]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load]);

  if (!hasPerm(me.perms, "movements") && !isAdmin)
    return (
      <EmptyState
        icon="🔒"
        title="لا تملك صلاحية عرض الحركة"
        sub="صلاحية «الحركة» تمنحها الإدارة من لوحة الصلاحيات"
      />
    );

  const filters: Array<{ key: typeof type; label: string }> = [
    { key: "all", label: "الكل" },
    { key: "add", label: "➕ إضافة" },
    { key: "remove", label: "➖ إخراج" },
    { key: "reconcile", label: "⚖️ تسوية" },
  ];

  return (
    <div className="space-y-4">
      <SectionTitle title="📋 سجل الحركة" />
      <div className="flex items-center gap-2 overflow-x-auto pb-0.5">
        {filters.map((f) => (
          <Button
            key={f.key}
            size="sm"
            variant={type === f.key ? "default" : "outline"}
            className="shrink-0 rounded-full text-xs h-8"
            onClick={() => setType(f.key)}
          >
            {f.label}
          </Button>
        ))}
        <Button
          size="sm"
          variant={mine ? "default" : "outline"}
          className="shrink-0 rounded-full text-xs h-8 ms-auto"
          onClick={() => setMine((v) => !v)}
        >
          👤 حركاتي فقط
        </Button>
      </div>

      {error ? <ErrorNote msg={error} /> : null}

      {rows === null ? (
        <LoadingBlock rows={6} />
      ) : rows.length === 0 ? (
        <EmptyState icon="📋" title="لا توجد حركات مطابقة" />
      ) : (
        <div className="rounded-xl border bg-card divide-y overflow-hidden">
          {rows.map((m) => {
            const meta = TYPE_META[m.type] ?? TYPE_META.add;
            return (
              <div key={m.id} className="flex items-center justify-between gap-2 px-4 py-3">
                <div className="min-w-0">
                  <p className="text-sm font-bold truncate">{m.product_name}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">
                    {meta.icon} {meta.label} · {m.user_name ?? "—"} · {fmtDateTime(m.date)}
                  </p>
                  {m.reason ? (
                    <p className="text-[11px] text-muted-foreground mt-0.5 truncate">💬 {m.reason}</p>
                  ) : null}
                </div>
                <span className={`shrink-0 text-lg font-extrabold ${meta.cls}`}>
                  {m.type === "remove" ? "−" : m.type === "add" ? "+" : ""}
                  {fmtNum(Math.abs(m.quantity))}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
