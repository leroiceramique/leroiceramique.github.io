"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";
import { useApp } from "@/components/app-context";
import { SectionTitle, EmptyState, LoadingBlock, ErrorNote, RoleBadge } from "@/components/ui-kit";
import { Switch } from "@/components/ui/switch";
import { PERM_LABELS } from "@/lib/perm";

const EDITABLE_ROLES = ["seller", "stock", "external"] as const;
const ROLE_TITLES: Record<string, string> = {
  seller: "🛍 بائع",
  stock: "📦 عامل مخزون",
  external: "🌍 بائع خارجي",
};
const ROLE_NOTES: Record<string, string> = {
  seller: "الفواتير والمبيعات وطلبات التوريد",
  stock: "تشغيل المخزون اليومي",
  external: "التوفر فقط دون كميات",
};

const PERM_ORDER = [
  "search", "add_qty", "remove", "invoice", "supply_order",
  "my_orders", "movements", "add_product", "edit_product", "low_stock", "pending",
] as const;

export function PermsView() {
  const { me } = useApp();
  const [matrix, setMatrix] = useState<Record<string, Record<string, boolean>> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const res = await api("/api/permissions");
    if (!res.ok) { setError(res.error ?? "فشل التحميل"); return; }
    setMatrix(res.matrix as Record<string, Record<string, boolean>>);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load]);

  if (!me.is_admin) return <EmptyState icon="🔒" title="لوحة الصلاحيات للإدارة فقط" />;

  async function toggle(role: string, perm: string, enabled: boolean) {
    const key = `${role}.${perm}`;
    setSaving(key);
    // تحديث متفائل ثم تنفيذ
    setMatrix((m) => (m ? { ...m, [role]: { ...m[role], [perm]: enabled } } : m));
    const res = await api("/api/permissions", {
      method: "POST",
      body: JSON.stringify({ role, perm, enabled }),
    });
    setSaving(null);
    if (!res.ok) {
      setError(res.error ?? "فشل الحفظ");
      load();
      return;
    }
    setError(null);
  }

  return (
    <div className="space-y-4">
      <SectionTitle title="🔐 الصلاحيات" />
      <p className="text-xs text-muted-foreground leading-relaxed">
        نفس نظام البوت: كل فئة لها صلاحياتها المخزنة في القاعدة، والتغيير يسري فوراً على
        تلغرام وتطبيق الويب معاً. فئتا «عميل» و«قيد المراجعة» خارج النظام (سلوكهما ثابت كما في البوت)،
        والفئات الإدارية تملك كل الصلاحيات دائماً.
      </p>
      {error ? <ErrorNote msg={error} /> : null}
      {matrix === null ? (
        <LoadingBlock rows={4} />
      ) : (
        <div className="space-y-4">
          {EDITABLE_ROLES.map((role) => (
            <div key={role} className="rounded-xl border bg-card p-4 shadow-sm space-y-3">
              <div>
                <RoleBadge role={role} />
                <p className="text-xs text-muted-foreground mt-1.5">{ROLE_NOTES[role]}</p>
              </div>
              <div className="rounded-lg border overflow-hidden divide-y">
                {PERM_ORDER.map((perm) => {
                  const key = `${role}.${perm}`;
                  return (
                    <div key={perm} className="flex items-center justify-between gap-3 px-3 py-2.5 bg-card">
                      <span className="text-sm">{PERM_LABELS[perm]}</span>
                      <Switch
                        checked={!!matrix[role]?.[perm]}
                        disabled={saving === key}
                        onCheckedChange={(v) => toggle(role, perm, v)}
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
