"use client";

import { useState } from "react";
import { api } from "@/lib/client";
import { useApp } from "@/components/app-context";
import { SectionTitle, PermChips, RoleBadge } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export function ProfileView() {
  const { me, refreshMe, installReady, promptInstall } = useApp();
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const isStandalone =
    typeof window !== "undefined" &&
    (window.matchMedia("(display-mode: standalone)").matches ||
      // iOS Safari
      (window.navigator as unknown as { standalone?: boolean }).standalone === true);

  async function submitPassword() {
    if (!cur || !next) { setError("املأ الحقلين"); return; }
    setBusy(true);
    setError(null);
    setMsg(null);
    const res = await api("/api/profile", {
      method: "POST",
      body: JSON.stringify({ current_password: cur, new_password: next }),
    });
    setBusy(false);
    if (!res.ok) { setError(res.error ?? "فشل التغيير"); return; }
    setMsg("تم تغيير كلمة المرور بنجاح");
    setCur("");
    setNext("");
  }

  async function logout() {
    await api("/api/auth/logout", { method: "POST" });
    await refreshMe();
  }

  return (
    <div className="space-y-4">
      <SectionTitle title="👤 ملفي" />

      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-3">
            <img src="/icons/icon-192.png" alt="" className="w-14 h-14 rounded-2xl ring-2 ring-primary/20" />
            <div className="min-w-0">
              <p className="font-extrabold text-lg leading-tight">{me.user.first_name ?? "—"}</p>
              <p className="text-xs text-muted-foreground" dir="ltr">@{me.user.username ?? "—"}</p>
            </div>
          </div>
          <Separator />
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">الفئة</span>
            <RoleBadge role={me.user.role} />
          </div>
          <div className="space-y-1.5">
            <span className="text-sm text-muted-foreground">صلاحياتي</span>
            <PermChips perms={me.perms} />
          </div>
        </CardContent>
      </Card>

      {/* التثبيت على الهاتف */}
      <Card className="border-primary/25">
        <CardContent className="p-4 space-y-2">
          <p className="font-bold text-sm">📲 تثبيت التطبيق على هاتفك</p>
          {isStandalone ? (
            <p className="text-xs text-emerald-700 dark:text-emerald-400">
              ✔ التطبيق مثبت ويعمل من الشاشة الرئيسية
            </p>
          ) : installReady ? (
            <>
              <p className="text-xs text-muted-foreground leading-relaxed">
                أضف التطبيق إلى شاشتك الرئيسية ليعمل بملء الشاشة كأي تطبيق آخر.
              </p>
              <Button className="w-full" onClick={promptInstall}>⬇️ تثبيت الآن</Button>
            </>
          ) : (
            <ol className="text-xs text-muted-foreground leading-relaxed space-y-1.5 list-decimal ps-4">
              <li><b>أندرويد (كروم):</b> قائمة ⋮ ثم «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».</li>
              <li><b>آيفون (سفاري):</b> زر المشاركة ⬆️ ثم «إضافة إلى الشاشة الرئيسية».</li>
              <li>سيظهر أيقونة التطبيق ويعمل بملء الشاشة بدون متصفح.</li>
            </ol>
          )}
        </CardContent>
      </Card>

      {/* تغيير كلمة المرور */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <p className="font-bold text-sm">🔑 تغيير كلمة مرور الويب</p>
          <div className="space-y-2">
            <Label htmlFor="pf-cur">كلمة المرور الحالية</Label>
            <Input id="pf-cur" type="password" dir="ltr" className="text-left" value={cur} onChange={(e) => setCur(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="pf-next">كلمة المرور الجديدة</Label>
            <Input id="pf-next" type="password" dir="ltr" className="text-left" value={next} onChange={(e) => setNext(e.target.value)} />
          </div>
          {error ? <p className="text-xs text-destructive">{error}</p> : null}
          {msg ? <p className="text-xs text-emerald-600 dark:text-emerald-400">✅ {msg}</p> : null}
          <Button className="w-full" variant="secondary" onClick={submitPassword} disabled={busy}>
            {busy ? "جارٍ التغيير…" : "تغيير كلمة المرور"}
          </Button>
        </CardContent>
      </Card>

      <Button className="w-full h-12 text-base" variant="outline" onClick={logout}>
        🚪 تسجيل الخروج
      </Button>
    </div>
  );
}
