"use client";

import { useCallback, useEffect, useState } from "react";
import { api, fmtNum, fmtDateTime } from "@/lib/client";
import { useApp, hasPerm } from "@/components/app-context";
import { SectionTitle, EmptyState, LoadingBlock, ErrorNote, ORDER_STATUS_META } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";

interface Order {
  id: number;
  product_name: string;
  quantity: number;
  status: string;
  created_at: string;
  completed_at: string | null;
  requester_name: string | null;
  requester_id: number;
}

export function OrdersView({ onMutated }: { onMutated?: () => void }) {
  const { me } = useApp();
  const isAdmin = me.is_admin;
  const canSupply = hasPerm(me.perms, "supply_order");
  const canSeeAll = isAdmin || hasPerm(me.perms, "pending");
  const canManage = isAdmin || hasPerm(me.perms, "pending");

  const [rows, setRows] = useState<Order[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<"pending" | "all">("pending");

  const [newOpen, setNewOpen] = useState(false);
  const [newName, setNewName] = useState("");
  const [newQty, setNewQty] = useState("");
  const [newBusy, setNewBusy] = useState(false);
  const [newError, setNewError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const res = await api("/api/orders");
    if (!res.ok) {
      setError(res.error ?? "فشل التحميل");
      setRows([]);
      return;
    }
    setRows((res.orders as Order[]) ?? []);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load]);

  if (!canSupply && !canSeeAll && !hasPerm(me.perms, "my_orders"))
    return (
      <EmptyState
        icon="🔒"
        title="لا تملك صلاحية طلبات التوريد"
        sub="صلاحية «طلب توريد جديد» أو «طلباتي» تمنحها الإدارة"
      />
    );

  async function submitNew() {
    const qty = Number(newQty);
    if (!newName.trim()) { setNewError("أدخل اسم السلعة المطلوبة"); return; }
    if (!Number.isInteger(qty) || qty <= 0) { setNewError("أدخل كمية صحيحة أكبر من صفر"); return; }
    setNewBusy(true);
    setNewError(null);
    const res = await api("/api/orders", {
      method: "POST",
      body: JSON.stringify({ product_name: newName, quantity: qty }),
    });
    setNewBusy(false);
    if (!res.ok) { setNewError(res.error ?? "فشل إنشاء الطلب"); return; }
    setNewOpen(false);
    setNewName("");
    setNewQty("");
    load();
    onMutated?.();
  }

  async function setStatus(order: Order, status: "received" | "completed") {
    const res = await api(`/api/orders/${order.id}`, {
      method: "PATCH",
      body: JSON.stringify({ status }),
    });
    if (!res.ok) { setError(res.error ?? "فشل تحديث الطلب"); return; }
    load();
    onMutated?.();
  }

  const visible = (rows ?? []).filter((o) => (filter === "pending" ? o.status === "pending" : true));

  return (
    <div className="space-y-4">
      <SectionTitle
        title="🚚 طلبات التوريد"
        action={
          canSupply ? (
            <Button size="sm" onClick={() => { setNewOpen(true); setNewError(null); }}>
              ＋ طلب جديد
            </Button>
          ) : null
        }
      />

      <div className="flex items-center gap-2">
        <Button size="sm" variant={filter === "pending" ? "default" : "outline"} className="rounded-full text-xs h-8"
          onClick={() => setFilter("pending")}>
          🔴 المعلقة
        </Button>
        <Button size="sm" variant={filter === "all" ? "default" : "outline"} className="rounded-full text-xs h-8"
          onClick={() => setFilter("all")}>
          الكل
        </Button>
      </div>

      {error ? <ErrorNote msg={error} /> : null}

      {rows === null ? (
        <LoadingBlock rows={4} />
      ) : visible.length === 0 ? (
        <EmptyState icon="🚚" title={filter === "pending" ? "لا طلبات معلقة" : "لا طلبات بعد"}
          sub={canSupply ? "أنشئ طلب توريد بزر «طلب جديد»" : undefined} />
      ) : (
        <div className="space-y-3">
          {visible.map((o) => {
            const st = ORDER_STATUS_META[o.status] ?? ORDER_STATUS_META.pending;
            const isMine = o.requester_id === me.user.id;
            return (
              <div key={o.id} className="rounded-xl border bg-card p-4 shadow-sm space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-bold">{o.product_name}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {o.requester_name ?? "—"} · {fmtDateTime(o.created_at)}
                      {isMine ? " (طلبك)" : ""}
                    </p>
                  </div>
                  <div className="text-left shrink-0">
                    <div className="text-xl font-extrabold">{fmtNum(o.quantity)}</div>
                    <Badge className={`text-[10px] mt-1 ${st.cls}`}>{st.label}</Badge>
                  </div>
                </div>
                {canManage && o.status === "pending" ? (
                  <div className="flex gap-2 pt-1">
                    <Button size="sm" variant="outline" className="h-8 text-xs rounded-full"
                      onClick={() => setStatus(o, "received")}>
                      📥 استلام
                    </Button>
                    <Button size="sm" variant="outline" className="h-8 text-xs rounded-full"
                      onClick={() => setStatus(o, "completed")}>
                      ✅ إكمال
                    </Button>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={newOpen} onOpenChange={setNewOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>📦 طلب توريد جديد</DialogTitle>
            <DialogDescription>سيرى الطلب المخزن والإدارة فوراً — وفي تلغرام أيضاً</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="o-name">السلعة المطلوبة</Label>
              <Input id="o-name" value={newName} onChange={(e) => setNewName(e.target.value)}
                placeholder="مثال: غرانيت 120×60 أسود" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="o-qty">الكمية</Label>
              <Input id="o-qty" type="number" inputMode="numeric" dir="ltr" className="text-left" value={newQty}
                onChange={(e) => setNewQty(e.target.value)} />
            </div>
            {newError ? <ErrorNote msg={newError} /> : null}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setNewOpen(false)}>إلغاء</Button>
            <Button onClick={submitNew} disabled={newBusy}>{newBusy ? "جارٍ الإرسال…" : "إرسال الطلب"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
