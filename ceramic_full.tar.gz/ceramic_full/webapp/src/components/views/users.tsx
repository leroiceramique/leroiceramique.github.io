"use client";

import { useCallback, useEffect, useState } from "react";
import { api, fmtDateTime } from "@/lib/client";
import { useApp } from "@/components/app-context";
import { SectionTitle, EmptyState, LoadingBlock, ErrorNote, RoleBadge } from "@/components/ui-kit";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface WUser {
  id: number;
  telegram_id: string;
  username: string | null;
  first_name: string | null;
  role: string;
  active: boolean;
  created_at: string;
  has_web_password: boolean;
  protected: boolean;
}

const ASSIGNABLE_ROLES = [
  { value: "manager", label: "🧑‍💼 مدير البوت" },
  { value: "stock", label: "📦 عامل مخزون" },
  { value: "seller", label: "🛍 بائع" },
  { value: "external", label: "🌍 بائع خارجي" },
  { value: "customer", label: "👤 عميل" },
  { value: "pending", label: "⏳ قيد المراجعة" },
];

export function UsersView() {
  const { me } = useApp();
  const [users, setUsers] = useState<WUser[] | null>(null);
  const [counters, setCounters] = useState<{ total: number; admins: number; kicked: number; pending: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // حوار تغيير الفئة
  const [roleTarget, setRoleTarget] = useState<WUser | null>(null);
  const [roleVal, setRoleVal] = useState("");
  const [roleBusy, setRoleBusy] = useState(false);
  const [roleError, setRoleError] = useState<string | null>(null);

  // تأكيد الطرد
  const [kickTarget, setKickTarget] = useState<WUser | null>(null);
  const [kickBusy, setKickBusy] = useState(false);
  const [kickError, setKickError] = useState<string | null>(null);

  // حوار كلمة المرور
  const [pwTarget, setPwTarget] = useState<WUser | null>(null);
  const [pwVal, setPwVal] = useState("");
  const [pwBusy, setPwBusy] = useState(false);
  const [pwError, setPwError] = useState<string | null>(null);

  // حوار إضافة مستخدم ويب
  const [addOpen, setAddOpen] = useState(false);
  const [addForm, setAddForm] = useState({ username: "", first_name: "", role: "customer", password: "" });
  const [addBusy, setAddBusy] = useState(false);
  const [addError, setAddError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setError(null);
    const res = await api("/api/users");
    if (!res.ok) { setError(res.error ?? "فشل التحميل"); setUsers([]); return; }
    setUsers((res.users as WUser[]) ?? []);
    setCounters((res.counters as typeof counters) ?? null);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load]);

  function flash(msg: string) {
    setNotice(msg);
    setTimeout(() => setNotice(null), 5000);
  }

  async function submitRole() {
    if (!roleTarget || !roleVal) return;
    setRoleBusy(true);
    setRoleError(null);
    const res = await api(`/api/users/${roleTarget.id}`, {
      method: "PATCH",
      body: JSON.stringify({ action: "role", role: roleVal }),
    });
    setRoleBusy(false);
    if (!res.ok) { setRoleError(res.error ?? "فشل التغيير"); return; }
    setRoleTarget(null);
    flash(res.message as string);
    load();
  }

  async function submitKick() {
    if (!kickTarget) return;
    setKickBusy(true);
    setKickError(null);
    const res = await api(`/api/users/${kickTarget.id}`, {
      method: "PATCH",
      body: JSON.stringify({ action: "active", active: false }),
    });
    setKickBusy(false);
    if (!res.ok) { setKickError(res.error ?? "فشل الطرد"); return; }
    setKickTarget(null);
    flash("تم طرد المستخدم وإيقاف وصوله من تلغرام والويب");
    load();
  }

  async function unban(u: WUser) {
    const res = await api(`/api/users/${u.id}`, {
      method: "PATCH",
      body: JSON.stringify({ action: "active", active: true }),
    });
    if (!res.ok) { setError(res.error ?? "فشل إعادة التنشيط"); return; }
    flash("تم إعادة تنشيط الحساب");
    load();
  }

  async function submitPassword() {
    if (!pwTarget) return;
    if (pwVal.length < 4) { setPwError("كلمة المرور يجب أن تكون 4 أحرف على الأقل"); return; }
    setPwBusy(true);
    setPwError(null);
    const res = await api(`/api/users/${pwTarget.id}`, {
      method: "PATCH",
      body: JSON.stringify({ action: "password", password: pwVal }),
    });
    setPwBusy(false);
    if (!res.ok) { setPwError(res.error ?? "فشل التعيين"); return; }
    setPwTarget(null);
    setPwVal("");
    flash("تم تعيين كلمة مرور الويب");
    load();
  }

  async function submitAdd() {
    setAddBusy(true);
    setAddError(null);
    const res = await api("/api/users", { method: "POST", body: JSON.stringify(addForm) });
    setAddBusy(false);
    if (!res.ok) { setAddError(res.error ?? "فشل الإنشاء"); return; }
    setAddOpen(false);
    setAddForm({ username: "", first_name: "", role: "customer", password: "" });
    flash("تم إنشاء مستخدم الويب — يمكنه الدخول الآن");
    load();
  }

  if (!me.is_admin) return <EmptyState icon="🔒" title="لوحة المستخدمين للإدارة فقط" />;

  return (
    <div className="space-y-4">
      <SectionTitle
        title="⚙️ المستخدمون"
        action={
          <Button size="sm" onClick={() => { setAddOpen(true); setAddError(null); }}>
            ＋ مستخدم ويب
          </Button>
        }
      />

      {counters ? (
        <div className="grid grid-cols-4 gap-2 text-center">
          {[
            { label: "الكل", value: counters.total, cls: "" },
            { label: "مدراء", value: counters.admins, cls: "text-primary" },
            { label: "مطرودون", value: counters.kicked, cls: "text-destructive" },
            { label: "قيد المراجعة", value: counters.pending, cls: "text-amber-600 dark:text-amber-400" },
          ].map((c) => (
            <div key={c.label} className="rounded-xl border bg-card py-2.5">
              <div className={`text-lg font-extrabold ${c.cls}`}>{c.value}</div>
              <div className="text-[10px] text-muted-foreground">{c.label}</div>
            </div>
          ))}
        </div>
      ) : null}

      {error ? <ErrorNote msg={error} /> : null}
      {notice ? (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-4 py-3 text-sm text-emerald-800 dark:text-emerald-300">
          ✅ {notice}
        </div>
      ) : null}

      {users === null ? (
        <LoadingBlock rows={5} />
      ) : users.length === 0 ? (
        <EmptyState icon="👥" title="لا مستخدمين" />
      ) : (
        <div className="space-y-3">
          {users.map((u) => {
            const isSelf = u.id === me.user.id;
            const isRoleAdmin = u.role === "admin" || u.role === "manager";
            const canTouch = !u.protected && !isSelf;
            return (
              <div key={u.id} className={`rounded-xl border bg-card p-4 shadow-sm space-y-2 ${u.active ? "" : "opacity-75 border-destructive/40"}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-bold flex items-center gap-1.5 flex-wrap">
                      <span className="truncate">{u.first_name ?? "—"}</span>
                      <span className="text-xs font-normal text-muted-foreground" dir="ltr">@{u.username ?? "—"}</span>
                      {isSelf ? <Badge variant="outline" className="text-[10px]">أنت</Badge> : null}
                      {u.protected ? <Badge variant="outline" className="text-[10px]">🛡 محمي</Badge> : null}
                    </p>
                    <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                      <RoleBadge role={u.role} />
                      {!u.active ? <Badge className="text-[10px] bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300">🚫 مطرود</Badge> : null}
                      {u.has_web_password ? <Badge variant="outline" className="text-[10px]">🔑 ويب</Badge> : null}
                    </div>
                  </div>
                  <div className="text-[10px] text-muted-foreground shrink-0 text-left">
                    {fmtDateTime(u.created_at)}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 pt-1">
                  {canTouch ? (
                    <Button size="sm" variant="outline" className="h-8 text-xs rounded-full"
                      onClick={() => { setRoleTarget(u); setRoleVal(u.role); setRoleError(null); }}>
                      🎯 الفئة
                    </Button>
                  ) : null}
                  {canTouch && u.active && !isRoleAdmin ? (
                    <Button size="sm" variant="outline" className="h-8 text-xs rounded-full text-destructive hover:text-destructive"
                      onClick={() => { setKickTarget(u); setKickError(null); }}>
                      🚫 طرد
                    </Button>
                  ) : null}
                  {canTouch && !u.active ? (
                    <Button size="sm" variant="outline" className="h-8 text-xs rounded-full text-emerald-700 hover:text-emerald-700"
                      onClick={() => unban(u)}>
                      ✅ إعادة تنشيط
                    </Button>
                  ) : null}
                  {canTouch ? (
                    <Button size="sm" variant="outline" className="h-8 text-xs rounded-full"
                      onClick={() => { setPwTarget(u); setPwVal(""); setPwError(null); }}>
                      🔑 كلمة مرور
                    </Button>
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* حوار الفئة */}
      <Dialog open={roleTarget !== null} onOpenChange={(o) => !o && setRoleTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>🎯 تغيير الفئة</DialogTitle>
            <DialogDescription>{roleTarget?.first_name} (@{roleTarget?.username ?? "—"}) — الفئة الحالية: {roleTarget?.role}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Select value={roleVal} onValueChange={setRoleVal}>
              <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
              <SelectContent>
                {ASSIGNABLE_ROLES.map((r) => (
                  <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {roleError ? <ErrorNote msg={roleError} /> : null}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setRoleTarget(null)}>إلغاء</Button>
            <Button onClick={submitRole} disabled={roleBusy || roleVal === roleTarget?.role}>
              {roleBusy ? "جارٍ التغيير…" : "تطبيق"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* تأكيد الطرد */}
      <AlertDialog open={kickTarget !== null} onOpenChange={(o) => !o && setKickTarget(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>🚫 طرد المستخدم؟</AlertDialogTitle>
            <AlertDialogDescription>
              «{kickTarget?.first_name}» (@{kickTarget?.username ?? "—"}) — سيُوقف وصوله من تلغرام
              وتطبيق الويب فوراً، مع بقاء سجله وتاريخ حركاته محفوظاً. يمكنك إعادة تنشيطه لاحقاً في أي وقت.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {kickError ? <ErrorNote msg={kickError} /> : null}
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={kickBusy}
              onClick={(e) => { e.preventDefault(); submitKick(); }}>
              {kickBusy ? "جارٍ الطرد…" : "تأكيد الطرد"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* حوار كلمة المرور */}
      <Dialog open={pwTarget !== null} onOpenChange={(o) => !o && setPwTarget(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>🔑 كلمة مرور الويب</DialogTitle>
            <DialogDescription>
              لـ {pwTarget?.first_name} (@{pwTarget?.username ?? "—"}) — حدد 4 أحرف على الأقل. جلساته المفتوحة ستُلغى.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <Input type="text" dir="ltr" className="text-left" value={pwVal} onChange={(e) => setPwVal(e.target.value)} placeholder="password" />
            {pwError ? <ErrorNote msg={pwError} /> : null}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setPwTarget(null)}>إلغاء</Button>
            <Button onClick={submitPassword} disabled={pwBusy}>{pwBusy ? "جارٍ الحفظ…" : "تعيين"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* حوار إضافة مستخدم ويب */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>➕ مستخدم ويب جديد</DialogTitle>
            <DialogDescription>
              مستخدم لا يحتاج حساب تلغرام إطلاقاً — يدخل من هذا التطبيق باسم مستخدم وكلمة مرور.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="nu-user">اسم المستخدم (للدخول)</Label>
              <Input id="nu-user" dir="ltr" className="text-left" value={addForm.username}
                onChange={(e) => setAddForm({ ...addForm, username: e.target.value })} placeholder="username" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="nu-name">الاسم الظاهر</Label>
              <Input id="nu-name" value={addForm.first_name}
                onChange={(e) => setAddForm({ ...addForm, first_name: e.target.value })} placeholder="مثال: سعاد البائعة" />
            </div>
            <div className="space-y-2">
              <Label>الفئة</Label>
              <Select value={addForm.role} onValueChange={(v) => setAddForm({ ...addForm, role: v })}>
                <SelectTrigger className="h-11"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ASSIGNABLE_ROLES.map((r) => (
                    <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="nu-pass">كلمة المرور</Label>
              <Input id="nu-pass" dir="ltr" className="text-left" value={addForm.password}
                onChange={(e) => setAddForm({ ...addForm, password: e.target.value })} placeholder="4 أحرف على الأقل" />
            </div>
            {addError ? <ErrorNote msg={addError} /> : null}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setAddOpen(false)}>إلغاء</Button>
            <Button onClick={submitAdd} disabled={addBusy}>{addBusy ? "جارٍ الإنشاء…" : "إنشاء"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
