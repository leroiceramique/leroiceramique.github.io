"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { api, fmtNum, fmtMoney } from "@/lib/client";
import { useApp, hasPerm } from "@/components/app-context";
import { SectionTitle, EmptyState, LoadingBlock, ErrorNote } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface Product {
  id: number;
  name: string;
  quantity?: number;
  location?: string | null;
  minimum_stock?: number;
  selling_price?: string;
  available?: boolean; // للبائع الخارجي فقط
}

interface ProductForm {
  name: string;
  location: string;
  minimum_stock: string;
  selling_price: string;
}

const EMPTY_FORM: ProductForm = { name: "", location: "", minimum_stock: "5", selling_price: "0" };

export function InventoryView({ onMutated }: { onMutated?: () => void }) {
  const { me } = useApp();
  const isAdmin = me.is_admin;
  const hideQty = me.hide_qty;
  const canSearch = hasPerm(me.perms, "search") || isAdmin || hideQty;
  const canAddProduct = hasPerm(me.perms, "add_product");
  const canAddQty = hasPerm(me.perms, "add_qty");
  const canRemove = hasPerm(me.perms, "remove");
  const canEdit = hasPerm(me.perms, "edit_product");
  const canLowStock = hasPerm(me.perms, "low_stock");

  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"name" | "qty" | "new">("name");
  const [onlyLow, setOnlyLow] = useState(false);
  const [products, setProducts] = useState<Product[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [deferredQ, setDeferredQ] = useState("");
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => setDeferredQ(q), 350);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [q]);

  const load = useCallback(async () => {
    setError(null);
    const params = new URLSearchParams();
    if (deferredQ.trim()) params.set("q", deferredQ.trim());
    params.set("sort", sort);
    const res = await api(`/api/products?${params.toString()}`);
    if (!res.ok) {
      setError(res.error ?? "فشل تحميل القائمة");
      setProducts([]);
      return;
    }
    let list = (res.products as Product[]) ?? [];
    if (onlyLow && !hideQty) list = list.filter((p) => (p.quantity ?? 0) <= (p.minimum_stock ?? 0));
    setProducts(list);
  }, [deferredQ, sort, onlyLow, hideQty]);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load, reloadKey]);

  function refresh() {
    setReloadKey((k) => k + 1);
    onMutated?.();
  }

  // ── حوارات الكميات ──
  const [qtyTarget, setQtyTarget] = useState<{ product: Product; type: "add" | "remove" | "reconcile" } | null>(null);
  const [qtyVal, setQtyVal] = useState("");
  const [qtyReason, setQtyReason] = useState("");
  const [qtyBusy, setQtyBusy] = useState(false);
  const [qtyError, setQtyError] = useState<string | null>(null);
  const [qtyWarning, setQtyWarning] = useState<string | null>(null);

  async function submitQty() {
    if (!qtyTarget) return;
    const n = Number(qtyVal);
    if (!Number.isInteger(n) || n <= 0) {
      setQtyError("أدخل كمية صحيحة أكبر من صفر");
      return;
    }
    setQtyBusy(true);
    setQtyError(null);
    const res = await api(`/api/products/${qtyTarget.product.id}/qty`, {
      method: "POST",
      body: JSON.stringify({ type: qtyTarget.type, quantity: n, reason: qtyReason }),
    });
    setQtyBusy(false);
    if (!res.ok) {
      setQtyError(res.error ?? "فشلت العملية");
      return;
    }
    setQtyWarning((res.warning as string) ?? null);
    setQtyTarget(null);
    setQtyVal("");
    setQtyReason("");
    refresh();
    if (res.warning) setTimeout(() => setQtyWarning(null), 6000);
  }

  // ── حوار إضافة/تعديل سلعة ──
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState<ProductForm>(EMPTY_FORM);
  const [formEditId, setFormEditId] = useState<number | null>(null);
  const [formBusy, setFormBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  function openAdd() {
    setForm(EMPTY_FORM);
    setFormEditId(null);
    setFormError(null);
    setFormOpen(true);
  }
  function openEdit(p: Product) {
    setForm({
      name: p.name,
      location: p.location ?? "",
      minimum_stock: String(p.minimum_stock ?? 5),
      selling_price: String(p.selling_price ?? "0"),
    });
    setFormEditId(p.id);
    setFormError(null);
    setFormOpen(true);
  }

  async function submitForm() {
    setFormBusy(true);
    setFormError(null);
    let res;
    if (formEditId) {
      res = await api(`/api/products/${formEditId}`, {
        method: "PATCH",
        body: JSON.stringify(form),
      });
    } else {
      res = await api(`/api/products`, {
        method: "POST",
        body: JSON.stringify({ ...form, quantity: 0 }),
      });
    }
    setFormBusy(false);
    if (!res.ok) {
      setFormError(res.error ?? "فشلت العملية");
      return;
    }
    setFormOpen(false);
    refresh();
  }

  // ── حوار الحذف ──
  const [deleteTarget, setDeleteTarget] = useState<Product | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  async function submitDelete() {
    if (!deleteTarget) return;
    setDeleteBusy(true);
    setDeleteError(null);
    const res = await api(`/api/products/${deleteTarget.id}`, { method: "DELETE" });
    setDeleteBusy(false);
    if (!res.ok) {
      setDeleteError(res.error ?? "فشل الحذف");
      return;
    }
    setDeleteTarget(null);
    refresh();
  }

  const noAccess = !canSearch && !canAddProduct;

  if (noAccess) {
    return (
      <EmptyState
        icon="🔒"
        title="لا تملك صلاحية عرض المخزون"
        sub="تحتاج صلاحية «البحث» أو «إضافة سلعة» — تواصل مع الإدارة لمنحها لك"
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 -mx-4 px-4 pt-1 pb-3 space-y-3">
        <SectionTitle
          title="المخزون"
          action={
            canAddProduct ? (
              <Button size="sm" onClick={openAdd}>
                ＋ سلعة جديدة
              </Button>
            ) : null
          }
        />
        <Input
          placeholder="🔍 ابحث باسم السلعة…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          className="h-11 rounded-xl"
        />
        <div className="flex items-center gap-2 overflow-x-auto pb-0.5">
          {canLowStock || isAdmin ? (
            <Button
              size="sm"
              variant={onlyLow ? "default" : "outline"}
              className="shrink-0 rounded-full text-xs h-8"
              onClick={() => setOnlyLow((v) => !v)}
            >
              ⚠️ منخفض فقط
            </Button>
          ) : null}
          <Button
            size="sm"
            variant={sort === "name" ? "default" : "outline"}
            className="shrink-0 rounded-full text-xs h-8"
            onClick={() => setSort("name")}
          >
            أ-ي
          </Button>
          {!hideQty && (
            <Button
              size="sm"
              variant={sort === "qty" ? "default" : "outline"}
              className="shrink-0 rounded-full text-xs h-8"
              onClick={() => setSort("qty")}
            >
              الأقل كمية
            </Button>
          )}
          <Button
            size="sm"
            variant={sort === "new" ? "default" : "outline"}
            className="shrink-0 rounded-full text-xs h-8"
            onClick={() => setSort("new")}
          >
            الأحدث
          </Button>
        </div>
      </div>

      {error ? <ErrorNote msg={error} /> : null}
      {qtyWarning ? (
        <div className="rounded-xl border border-amber-300 bg-amber-50 dark:bg-amber-950/40 px-4 py-3 text-sm text-amber-800 dark:text-amber-300">
          ⚠️ {qtyWarning}
        </div>
      ) : null}

      {products === null ? (
        <LoadingBlock rows={5} />
      ) : products.length === 0 ? (
        <EmptyState
          icon="📦"
          title={deferredQ ? "لا نتائج مطابقة" : "لا توجد سلع بعد"}
          sub={canAddProduct ? "ابدأ بإضافة أول سلعة بزر «سلعة جديدة»" : "سيظهر المخزون هنا عند إضافته"}
        />
      ) : (
        <div className="space-y-3">
          {products.map((p) => {
            const qty = p.quantity ?? 0;
            const min = p.minimum_stock ?? 0;
            const low = !hideQty && qty <= min;
            return (
              <div key={p.id} className="rounded-xl border bg-card p-4 shadow-sm space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-bold leading-snug">{p.name}</p>
                    {p.location ? (
                      <p className="text-xs text-muted-foreground mt-1">📍 {p.location}</p>
                    ) : null}
                  </div>
                  {hideQty ? (
                    <Badge className={p.available ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300" : "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300"}>
                      {p.available ? "متوفر" : "غير متوفر"}
                    </Badge>
                  ) : (
                    <div className="text-left shrink-0">
                      <div className={`text-xl font-extrabold leading-none ${qty === 0 ? "text-destructive" : low ? "text-amber-600 dark:text-amber-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                        {fmtNum(qty)}
                      </div>
                      <div className="text-[10px] text-muted-foreground mt-1">الحد الأدنى {fmtNum(min)}</div>
                    </div>
                  )}
                </div>
                {!hideQty && p.selling_price !== undefined ? (
                  <p className="text-xs text-muted-foreground">💵 سعر البيع: {fmtMoney(p.selling_price)}</p>
                ) : null}
                {!hideQty ? (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {canAddQty ? (
                      <Button size="sm" variant="outline" className="h-8 text-xs rounded-full"
                        onClick={() => { setQtyTarget({ product: p, type: "add" }); setQtyVal(""); setQtyReason(""); setQtyError(null); }}>
                        ➕ كمية
                      </Button>
                    ) : null}
                    {canRemove ? (
                      <Button size="sm" variant="outline" className="h-8 text-xs rounded-full"
                        onClick={() => { setQtyTarget({ product: p, type: "remove" }); setQtyVal(""); setQtyReason(""); setQtyError(null); }}>
                        ➖ إخراج
                      </Button>
                    ) : null}
                    {canEdit ? (
                      <Button size="sm" variant="outline" className="h-8 text-xs rounded-full" onClick={() => openEdit(p)}>
                        ✏️ تعديل
                      </Button>
                    ) : null}
                    {isAdmin ? (
                      <>
                        <Button size="sm" variant="outline" className="h-8 text-xs rounded-full"
                          onClick={() => { setQtyTarget({ product: p, type: "reconcile" }); setQtyVal(""); setQtyReason(""); setQtyError(null); }}>
                          ⚖️ جرد
                        </Button>
                        <Button size="sm" variant="outline" className="h-8 text-xs rounded-full text-destructive hover:text-destructive"
                          onClick={() => { setDeleteTarget(p); setDeleteError(null); }}>
                          🗑 حذف
                        </Button>
                      </>
                    ) : null}
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      )}

      {/* حوار الكمية */}
      <Dialog open={qtyTarget !== null} onOpenChange={(o) => !o && setQtyTarget(null)}>
        <DialogContent className="max-w-sm">
          {qtyTarget ? (
            <>
              <DialogHeader>
                <DialogTitle>
                  {qtyTarget.type === "add" ? "➕ إضافة كمية" : qtyTarget.type === "remove" ? "➖ إخراج كمية" : "⚖️ جرد — الكمية الفعلية"}
                </DialogTitle>
                <DialogDescription>{qtyTarget.product.name}</DialogDescription>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-2">
                  <Label htmlFor="qty-val">{qtyTarget.type === "reconcile" ? "الكمية الفعلية بعد الجرد" : "الكمية"}</Label>
                  <Input id="qty-val" type="number" inputMode="numeric" dir="ltr" className="text-left h-11" value={qtyVal}
                    onChange={(e) => setQtyVal(e.target.value)} autoFocus />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="qty-reason">السبب (اختياري)</Label>
                  <Textarea id="qty-reason" rows={2} placeholder="مثال: شحنة جديدة / طلب زبون…"
                    value={qtyReason} onChange={(e) => setQtyReason(e.target.value)} />
                </div>
                {qtyError ? <ErrorNote msg={qtyError} /> : null}
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setQtyTarget(null)}>إلغاء</Button>
                <Button onClick={submitQty} disabled={qtyBusy}>
                  {qtyBusy ? "جارٍ التنفيذ…" : "تأكيد"}
                </Button>
              </DialogFooter>
            </>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* حوار إضافة/تعديل سلعة */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{formEditId ? "✏️ تعديل سلعة" : "📦 إضافة سلعة جديدة"}</DialogTitle>
            <DialogDescription>
              {formEditId ? "عدّل بيانات السلعة ثم احفظ" : "ستُسجَّل السلعة بكمية 0 — أضف الكمية بعدها"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="p-name">اسم السلعة</Label>
              <Input id="p-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="مثال: بورسلان 60×60 بيج" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="p-loc">الموقع في المخزن</Label>
              <Input id="p-loc" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="مثال: المخزن أ — رف 3" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="p-min">الحد الأدنى</Label>
                <Input id="p-min" type="number" inputMode="numeric" dir="ltr" className="text-left" value={form.minimum_stock}
                  onChange={(e) => setForm({ ...form, minimum_stock: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="p-price">سعر البيع (د.ج)</Label>
                <Input id="p-price" type="number" inputMode="decimal" dir="ltr" className="text-left" value={form.selling_price}
                  onChange={(e) => setForm({ ...form, selling_price: e.target.value })} />
              </div>
            </div>
            {formError ? <ErrorNote msg={formError} /> : null}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setFormOpen(false)}>إلغاء</Button>
            <Button onClick={submitForm} disabled={formBusy}>
              {formBusy ? "جارٍ الحفظ…" : "حفظ"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* تأكيد الحذف */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>🗑 حذف السلعة؟</AlertDialogTitle>
            <AlertDialogDescription>
              «{deleteTarget?.name}» — لا يمكن الرجوع بعد الحذف. السلع ذات الحركات المسجلة لن تُحذف.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {deleteError ? <ErrorNote msg={deleteError} /> : null}
          <AlertDialogFooter className="gap-2">
            <AlertDialogCancel>تراجع</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteBusy}
              onClick={(e) => { e.preventDefault(); submitDelete(); }}
            >
              {deleteBusy ? "جارٍ الحذف…" : "حذف نهائي"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
