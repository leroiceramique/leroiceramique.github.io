"use client";

import { useCallback, useEffect, useState } from "react";
import { api, fmtNum, fmtDateTime, daysSince } from "@/lib/client";
import { useApp } from "@/components/app-context";
import { SectionTitle, LoadingBlock, ErrorNote } from "@/components/ui-kit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";

interface OilStatus {
  baseline: number;
  current: number | null;
  since_change: number | null;
  last_change_at: string | null;
  current_hours_at: string | null;
  rate_per_day: number | null;
  predicted_250_at: string | null;
}

export function OilView() {
  const { me } = useApp();
  const isAdmin = me.is_admin;
  const canRead = isAdmin || me.user.role === "stock";

  const [status, setStatus] = useState<OilStatus | null>(null);
  const [readings, setReadings] = useState<Array<{ reading: string; read_at: string; by_name: string }>>([]);
  const [log, setLog] = useState<Array<{ changed_at: string; hours_at_change: string | null; recorded_by_name: string; note: string | null }>>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [readOpen, setReadOpen] = useState(false);
  const [readVal, setReadVal] = useState("");
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await api("/api/oil");
    setLoading(false);
    if (!res.ok) { setError(res.error ?? "فشل التحميل"); return; }
    setStatus((res.status as OilStatus) ?? null);
    setReadings((res.readings as typeof readings) ?? []);
    setLog((res.log as typeof log) ?? []);
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    load();
  }, [load]);

  async function submitReading() {
    const v = Number(readVal);
    if (!Number.isFinite(v) || v < 0) { setFormError("أدخل قراءة عداد صحيحة"); return; }
    setBusy(true);
    setFormError(null);
    const res = await api("/api/oil", { method: "POST", body: JSON.stringify({ action: "reading", reading: v }) });
    setBusy(false);
    if (!res.ok) { setFormError(res.error ?? "فشل التسجيل"); return; }
    setReadOpen(false);
    setReadVal("");
    load();
  }

  async function submitChange() {
    const v = Number(readVal);
    if (!Number.isFinite(v) || v < 0) { setFormError("أدخل ساعات العمل عند التغيير"); return; }
    setBusy(true);
    setFormError(null);
    const res = await api("/api/oil", { method: "POST", body: JSON.stringify({ action: "change", hours: v, note: "" }) });
    setBusy(false);
    if (!res.ok) { setFormError(res.error ?? "فشل التسجيل"); return; }
    setReadOpen(false);
    setReadVal("");
    load();
  }

  const sinceDays = daysSince(status?.last_change_at);
  const pct = status ? Math.min(100, Math.round(((status.since_change ?? 0) / 250) * 100)) : 0;

  return (
    <div className="space-y-4">
      <SectionTitle
        title="🛠️ زيت الرافعة الشوكية"
        action={canRead ? (
          <Button size="sm" onClick={() => { setReadOpen(true); setReadVal(""); setFormError(null); }}>
            ＋ تسجيل
          </Button>
        ) : null}
      />

      {error ? <ErrorNote msg={error} /> : null}
      {loading ? (
        <LoadingBlock rows={3} />
      ) : status ? (
        <>
          <Card className="border-primary/25">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">ساعات العمل منذ آخر تغيير زيت</p>
                  <p className={`text-4xl font-extrabold leading-none mt-1 ${pct >= 80 ? "text-destructive" : pct >= 60 ? "text-amber-600 dark:text-amber-400" : "text-emerald-600 dark:text-emerald-400"}`}>
                    {fmtNum(status.since_change ?? 0)}
                  </p>
                </div>
                <div className="text-left text-xs text-muted-foreground space-y-0.5">
                  <p>القراءة الحالية: <b>{fmtNum(status.current ?? 0)}</b></p>
                  <p>خط الأساس: <b>{fmtNum(status.baseline)}</b></p>
                  {sinceDays !== null ? <p>آخر تغيير: <b>{sinceDays} يوم</b> مضى</p> : null}
                </div>
              </div>
              <div className="h-2.5 rounded-full bg-muted overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${pct >= 80 ? "bg-destructive" : pct >= 60 ? "bg-amber-500" : "bg-emerald-500"}`}
                  style={{ width: `${pct}%` }}
                />
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="rounded-lg bg-secondary/60 px-3 py-2">
                  <p className="text-muted-foreground">معدل الاستهلاك</p>
                  <p className="font-bold mt-0.5">{status.rate_per_day === null ? "—" : `${fmtNum(status.rate_per_day)} ساعة/يوم`}</p>
                </div>
                <div className="rounded-lg bg-secondary/60 px-3 py-2">
                  <p className="text-muted-foreground">التنبؤ بوصول 250 س</p>
                  <p className="font-bold mt-0.5">{status.predicted_250_at ? fmtDateTime(status.predicted_250_at) : "—"}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div>
            <p className="text-sm font-bold mb-2">📜 آخر القراءات</p>
            <div className="rounded-xl border bg-card divide-y overflow-hidden">
              {readings.length === 0 ? (
                <p className="px-4 py-4 text-sm text-muted-foreground text-center">لا قراءات بعد</p>
              ) : (
                readings.map((r, i) => (
                  <div key={i} className="flex items-center justify-between px-4 py-2.5">
                    <span className="text-xs text-muted-foreground">{r.by_name ?? "—"} · {fmtDateTime(r.read_at)}</span>
                    <span className="font-extrabold">{fmtNum(r.reading)}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <p className="text-sm font-bold mb-2">🔧 سجل تغيير الزيت</p>
            <div className="rounded-xl border bg-card divide-y overflow-hidden">
              {log.length === 0 ? (
                <p className="px-4 py-4 text-sm text-muted-foreground text-center">لا تغييرات مسجلة</p>
              ) : (
                log.map((l, i) => (
                  <div key={i} className="px-4 py-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">{l.recorded_by_name ?? "—"} · {fmtDateTime(l.changed_at)}</span>
                      <span className="font-extrabold">{fmtNum(l.hours_at_change ?? 0)} س</span>
                    </div>
                    {l.note ? <p className="text-xs text-muted-foreground mt-0.5">💬 {l.note}</p> : null}
                  </div>
                ))
              )}
            </div>
          </div>
        </>
      ) : null}

      {/* حوار التسجيل */}
      <Dialog open={readOpen} onOpenChange={setReadOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>🔧 تسجيل بيانات الزيت</DialogTitle>
            <DialogDescription>
              «قراءة» تسجّل قراءة عداد الساعات الحالية. «تغيير زيت» يبدأ دورة جديدة بخط أساس جديد.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="oil-val">{readVal && false ? "" : "قراءة العداد (ساعات العمل)"}</Label>
              <Input id="oil-val" type="number" inputMode="decimal" dir="ltr" className="text-left h-11"
                value={readVal} onChange={(e) => setReadVal(e.target.value)} autoFocus />
            </div>
            {formError ? <ErrorNote msg={formError} /> : null}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setReadOpen(false)}>إلغاء</Button>
            {isAdmin ? (
              <Button variant="secondary" onClick={submitChange} disabled={busy}>🔧 تغيير زيت (دورة جديدة)</Button>
            ) : null}
            <Button onClick={submitReading} disabled={busy}>{busy ? "جارٍ التسجيل…" : "تسجيل قراءة"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
