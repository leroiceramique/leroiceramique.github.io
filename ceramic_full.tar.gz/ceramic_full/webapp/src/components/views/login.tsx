"use client";

import { useState } from "react";
import { api } from "@/lib/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { ErrorNote } from "@/components/ui-kit";

export function LoginView({ onLoggedIn }: { onLoggedIn: () => void }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e?: React.FormEvent) {
    e?.preventDefault();
    if (!username.trim() || !password) {
      setError("أدخل اسم المستخدم وكلمة المرور");
      return;
    }
    setBusy(true);
    setError(null);
    const res = await api("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    });
    setBusy(false);
    if (!res.ok) {
      setError(res.error ?? "فشل تسجيل الدخول");
      return;
    }
    onLoggedIn();
  }

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center px-4 bg-gradient-to-b from-primary/10 via-background to-background">
      <div className="w-full max-w-sm space-y-6">
        <div className="flex flex-col items-center gap-3 text-center">
          <img
            src="/icons/icon-192.png"
            alt="شعار مخزون السيراميك"
            className="w-24 h-24 rounded-3xl shadow-lg ring-4 ring-primary/15"
          />
          <div>
            <h1 className="text-2xl font-extrabold">مخزون السيراميك</h1>
            <p className="text-sm text-muted-foreground mt-1">
              تطبيق إدارة المخزون — متزامن مباشرة مع بوت تلغرام
            </p>
          </div>
        </div>

        <Card className="shadow-md">
          <CardContent className="pt-6">
            <form onSubmit={submit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">اسم المستخدم</Label>
                <Input
                  id="username"
                  autoComplete="username"
                  dir="ltr"
                  className="text-left"
                  placeholder="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">كلمة المرور</Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  dir="ltr"
                  className="text-left"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              {error ? <ErrorNote msg={error} /> : null}
              <Button type="submit" className="w-full h-11 text-base font-bold" disabled={busy}>
                {busy ? "جارٍ الدخول…" : "تسجيل الدخول"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <p className="text-center text-[11px] text-muted-foreground leading-relaxed px-2">
          حساب الويب تُنشئه الإدارة من لوحة المستخدمين.
          <br />
          إذا لم تملك حساباً تواصل مع إدارة المخزون.
        </p>
      </div>
    </div>
  );
}
