"use client";

import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ROLE_LABELS, PERM_LABELS, type Perm } from "@/lib/perm";
import type { ReactNode } from "react";

export type Role = "admin" | "manager" | "stock" | "seller" | "external" | "customer" | "pending";

export function RoleBadge({ role }: { role: string }) {
  return (
    <Badge variant="secondary" className="text-[11px] gap-1 bg-secondary text-secondary-foreground">
      {ROLE_LABELS[role as Role] ?? role}
    </Badge>
  );
}

export function PermChips({ perms }: { perms: Perm[] }) {
  if (perms.length === 0)
    return <p className="text-sm text-muted-foreground">لا توجد صلاحيات مفعّلة</p>;
  return (
    <div className="flex flex-wrap gap-1.5">
      {perms.map((p) => (
        <Badge key={p} variant="outline" className="text-[11px] font-normal">
          {PERM_LABELS[p] ?? p}
        </Badge>
      ))}
    </div>
  );
}

export function StatCard({
  icon,
  label,
  value,
  hint,
  tone = "default",
  onClick,
}: {
  icon: ReactNode;
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "warn" | "danger" | "good";
  onClick?: () => void;
}) {
  const toneClass =
    tone === "warn"
      ? "text-amber-600 dark:text-amber-400"
      : tone === "danger"
        ? "text-destructive"
        : tone === "good"
          ? "text-emerald-600 dark:text-emerald-400"
          : "text-primary";
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-right rounded-xl border bg-card p-4 shadow-sm transition-all flex flex-col gap-2 ${
        onClick ? "hover:shadow-md hover:-translate-y-0.5 active:scale-[0.98]" : "cursor-default"
      }`}
    >
      <div className={`flex items-center gap-2 ${toneClass}`}>
        {icon}
        <span className="text-xs font-medium text-muted-foreground">{label}</span>
      </div>
      <div className={`text-2xl font-extrabold leading-none ${toneClass}`}>{value}</div>
      {hint ? <div className="text-[11px] text-muted-foreground">{hint}</div> : null}
    </button>
  );
}

export function SectionTitle({ icon, title, action }: { icon?: ReactNode; title: string; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2 mb-3">
      <h2 className="text-base font-bold flex items-center gap-2">
        {icon}
        {title}
      </h2>
      {action}
    </div>
  );
}

export function EmptyState({ icon, title, sub }: { icon?: ReactNode; title: string; sub?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
      <div className="text-4xl opacity-60">{icon ?? "🗂️"}</div>
      <p className="font-semibold text-sm">{title}</p>
      {sub ? <p className="text-xs text-muted-foreground max-w-60">{sub}</p> : null}
    </div>
  );
}

export function LoadingBlock({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-2">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-14 w-full rounded-xl" />
      ))}
    </div>
  );
}

export function ErrorNote({ msg }: { msg: string }) {
  return (
    <div className="rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive whitespace-pre-line">
      {msg}
    </div>
  );
}

export const TYPE_META: Record<string, { label: string; icon: string; cls: string }> = {
  add: { label: "إضافة", icon: "➕", cls: "text-emerald-600 dark:text-emerald-400" },
  remove: { label: "إخراج", icon: "➖", cls: "text-destructive" },
  reconcile: { label: "تسوية", icon: "⚖️", cls: "text-amber-600 dark:text-amber-400" },
};

export const ORDER_STATUS_META: Record<string, { label: string; cls: string }> = {
  pending: { label: "معلق", cls: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300" },
  received: { label: "مُستلم", cls: "bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300" },
  completed: { label: "مكتمل", cls: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300" },
};

export const INVOICE_STATUS_META: Record<string, { label: string; cls: string }> = {
  draft: { label: "مسودة", cls: "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300" },
  approved: { label: "معتمدة", cls: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300" },
  cancelled: { label: "ملغاة", cls: "bg-red-100 text-red-700 dark:bg-red-950 dark:text-red-300" },
};
