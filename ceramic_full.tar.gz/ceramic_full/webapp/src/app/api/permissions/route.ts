import { requireAdmin, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { PERMS, EDITABLE_PERM_ROLES_LIST, PERM_LABELS } from "@/lib/perm";
import { query } from "@/lib/db";
import { ok, fail, readBody, requireStr } from "@/lib/api";

// GET /api/permissions — مصفوفة الصلاحيات للفئات القابلة للإدارة
export async function GET() {
  try {
    await requireAdmin();
    const rows = await query<{ role: string; perm: string; enabled: boolean }>(
      "SELECT role, perm, enabled FROM role_permissions"
    );
    const matrix: Record<string, Record<string, boolean>> = {};
    for (const role of EDITABLE_PERM_ROLES_LIST) {
      matrix[role] = {};
      for (const perm of PERMS) matrix[role][perm] = false;
    }
    for (const r of rows) {
      if (matrix[r.role] && (PERMS as readonly string[]).includes(r.perm))
        matrix[r.role][r.perm] = r.enabled;
    }
    return ok({ matrix, perms: PERMS, perm_labels: PERM_LABELS });
  } catch (err) {
    return fail(err);
  }
}

// POST /api/permissions — تبديل صلاحية فئة {role, perm, enabled}
export async function POST(req: Request) {
  try {
    const admin = await requireAdmin();
    const b = await readBody<{ role?: string; perm?: string; enabled?: boolean }>(req);
    const role = requireStr(b.role, "الفئة", 20);
    const perm = requireStr(b.perm, "الصلاحية", 60);
    if (typeof b.enabled !== "boolean") throw new ApiError("قيمة التفعيل غير صالحة", 400);
    if (!EDITABLE_PERM_ROLES_LIST.includes(role))
      throw new ApiError("هذه الفئة غير قابلة للتعديل (مطابق لنظام البوت)", 400);
    if (!(PERMS as readonly string[]).includes(perm))
      throw new ApiError("صلاحية غير معروفة", 400);

    await query(
      `INSERT INTO role_permissions (role, perm, enabled) VALUES ($1, $2, $3)
       ON CONFLICT (role, perm) DO UPDATE SET enabled = $3`,
      [role, perm, b.enabled]
    );
    await logAction(
      admin.id,
      "perm_toggle",
      `${role}.${perm} = ${b.enabled}`
    );
    return ok();
  } catch (err) {
    return fail(err);
  }
}
