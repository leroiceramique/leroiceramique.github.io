import { cookies } from "next/headers";
import {
  SESSION_COOKIE,
  destroySession,
  clearSessionCookie,
  getSessionUserByToken,
} from "@/lib/auth";
import { logAction } from "@/lib/db";
import { ok, fail } from "@/lib/api";

export async function POST() {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (token) {
      const user = await getSessionUserByToken(token);
      await destroySession(token);
      if (user) await logAction(user.id, "logout", `@${user.username}`);
    }
    await clearSessionCookie();
    return ok();
  } catch (err) {
    return fail(err);
  }
}
