import { login, setSessionCookie } from "@/lib/auth";
import { ok, fail, readBody, requireStr } from "@/lib/api";

export async function POST(req: Request) {
  try {
    const b = await readBody<{ username?: string; password?: string }>(req);
    const username = requireStr(b.username, "اسم المستخدم", 255);
    const password = requireStr(b.password, "كلمة المرور", 255);
    const res = await login(username, password);
    if (!res.ok) {
      if (res.reason === "kicked")
        return Response.json(
          {
            ok: false,
            error:
              "⛔ تم إيقاف حسابك من قبل الإدارة.\nللاستفسار تواصل مع إدارة البوت.",
          },
          { status: 403 }
        );
      return Response.json(
        { ok: false, error: "اسم المستخدم أو كلمة المرور غير صحيحة" },
        { status: 401 }
      );
    }
    await setSessionCookie(res.token);
    return ok({ user: res.user });
  } catch (err) {
    return fail(err);
  }
}
