import { getSessionUser, effectivePerms } from "@/lib/auth";
import { userIsAdmin } from "@/lib/perm";
import { query, queryOne } from "@/lib/db";
import { ok, fail } from "@/lib/api";

// GET /api/dashboard — إحصائيات الرئيسية حسب صلاحيات المستخدم
export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) return Response.json({ ok: false, error: "يجب تسجيل الدخول أولاً" }, { status: 401 });
    const perms = await effectivePerms(user);
    const isAdmin = userIsAdmin(user);
    const has = (p: string) => perms.includes(p as never) || isAdmin;

    const payload: Record<string, unknown> = {};

    if (has("search") || isAdmin) {
      const totals = await queryOne<{ products: string; quantity: string; value: string }>(
        `SELECT COUNT(*)::text AS products,
                COALESCE(SUM(quantity), 0)::text AS quantity,
                COALESCE(SUM(quantity * selling_price), 0)::text AS value
         FROM products`
      );
      payload.totals = {
        products: Number(totals?.products ?? 0),
        quantity: Number(totals?.quantity ?? 0),
        value: Number(totals?.value ?? 0),
      };
    }

    if (has("low_stock") || isAdmin) {
      const low = await queryOne<{ n: string }>(
        "SELECT COUNT(*)::text AS n FROM products WHERE quantity <= minimum_stock"
      );
      payload.low_count = Number(low?.n ?? 0);
    }

    if ((has("supply_order") || has("my_orders") || has("pending") || isAdmin)) {
      const myPending = await queryOne<{ n: string }>(
        "SELECT COUNT(*)::text AS n FROM incoming_orders WHERE status = 'pending' AND requester_id = $1",
        [user.id]
      );
      payload.my_pending_orders = Number(myPending?.n ?? 0);
      if (has("pending") || isAdmin) {
        const allPending = await queryOne<{ n: string }>(
          "SELECT COUNT(*)::text AS n FROM incoming_orders WHERE status = 'pending'"
        );
        payload.all_pending_orders = Number(allPending?.n ?? 0);
      }
    }

    if (has("movements") || isAdmin) {
      payload.recent_movements = await query(
        `SELECT t.type, t.quantity, t.date::text, p.name AS product_name,
                u.first_name AS user_name
         FROM transactions t
         JOIN products p ON p.id = t.product_id
         JOIN users u ON u.id = t.user_id
         ORDER BY t.date DESC LIMIT 6`
      );
    }

    if (has("invoice") || isAdmin) {
      const inv = await queryOne<{ total: string; n: string }>(
        `SELECT COALESCE(SUM(total_amount), 0)::text AS total, COUNT(*)::text AS n
         FROM invoices
         WHERE status = 'approved' AND created_at >= date_trunc('month', NOW())`
      );
      payload.month_invoices = { total: Number(inv?.total ?? 0), count: Number(inv?.n ?? 0) };
      const draftInv = await queryOne<{ n: string }>(
        "SELECT COUNT(*)::text AS n FROM invoices WHERE status = 'draft'"
      );
      payload.draft_invoices = Number(draftInv?.n ?? 0);
    }

    // زيت الرافعة — نبذة للجميع
    const oil = await queryOne<{ current_hours: string; baseline_hours: string }>(
      "SELECT current_hours::text, baseline_hours::text FROM oil_status WHERE id = 1"
    );
    if (oil) {
      payload.oil = {
        current: Number(oil.current_hours ?? 0),
        baseline: Number(oil.baseline_hours ?? 0),
        since_change: Number(oil.current_hours ?? 0) - Number(oil.baseline_hours ?? 0),
      };
    }

    return ok({ stats: payload });
  } catch (err) {
    return fail(err);
  }
}
