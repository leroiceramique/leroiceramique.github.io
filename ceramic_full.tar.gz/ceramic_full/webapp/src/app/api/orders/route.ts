import { requireUser, effectivePerms, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { userIsAdmin } from "@/lib/perm";
import { query } from "@/lib/db";
import { ok, fail, readBody, requireStr, toPosInt } from "@/lib/api";

// GET /api/orders — طلبات التوريد
// الإدارة/صاحب صلاحية pending → كل الطلبات | غيره → طلباته فقط
export async function GET() {
  try {
    const user = await requireUser();
    const perms = await effectivePerms(user);
    const isAdmin = userIsAdmin(user);
    const seeAll = isAdmin || perms.includes("pending");
    if (!seeAll && !perms.includes("my_orders") && !perms.includes("supply_order"))
      throw new ApiError("لا تملك صلاحية عرض طلبات التوريد", 403);

    const rows = await query(
      `SELECT o.id, o.product_name, o.quantity, o.status, o.created_at::text,
              o.completed_at::text, u.first_name AS requester_name, o.requester_id
       FROM incoming_orders o
       JOIN users u ON u.id = o.requester_id
       ${seeAll ? "" : "WHERE o.requester_id = $1"}
       ORDER BY o.created_at DESC LIMIT 200`,
      seeAll ? [] : [user.id]
    );
    return ok({ orders: rows, see_all: seeAll });
  } catch (err) {
    return fail(err);
  }
}

// POST /api/orders — طلب توريد جديد (صلاحية supply_order)
export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const perms = await effectivePerms(user);
    if (!userIsAdmin(user) && !perms.includes("supply_order"))
      throw new ApiError("لا تملك صلاحية إنشاء طلب توريد", 403);

    const b = await readBody<{ product_name?: string; quantity?: unknown }>(req);
    const name = requireStr(b.product_name, "اسم السلعة المطلوبة", 500);
    const qty = toPosInt(b.quantity, "الكمية");

    const created = await query<{ id: number }>(
      `INSERT INTO incoming_orders (requester_id, product_name, quantity)
       VALUES ($1, $2, $3) RETURNING id`,
      [user.id, name, qty]
    );
    await logAction(user.id, "order_create", `${name} × ${qty}`);
    return ok({ id: created[0].id });
  } catch (err) {
    return fail(err);
  }
}
