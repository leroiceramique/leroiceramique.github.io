import { requireUser, effectivePerms, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { userIsAdmin } from "@/lib/perm";
import { query } from "@/lib/db";
import { ok, fail, readBody } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

// PATCH /api/orders/:id — تغيير حالة طلب توريد
// {status: "received"|"completed"} — للإدارة أو صاحب صلاحية pending
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    const perms = await effectivePerms(user);
    if (!userIsAdmin(user) && !perms.includes("pending"))
      throw new ApiError("إدارة الطلبات متاحة للإدارة فقط", 403);

    const { id } = await ctx.params;
    const oid = Number(id);
    if (!Number.isInteger(oid) || oid <= 0) throw new ApiError("معرّف غير صالح", 400);

    const b = await readBody<{ status?: string }>(req);
    if (b.status !== "received" && b.status !== "completed")
      throw new ApiError("حالة غير صالحة", 400);

    const exists = await query<{ id: number }>("SELECT id FROM incoming_orders WHERE id = $1", [oid]);
    if (exists.length === 0) throw new ApiError("الطلب غير موجود", 404);

    await query(
      `UPDATE incoming_orders
       SET status = $1::varchar,
           completed_at = CASE WHEN $1::varchar = 'completed' THEN NOW() ELSE completed_at END
       WHERE id = $2`,
      [b.status, oid]
    );
    await logAction(user.id, `order_${b.status}`, `#${oid}`);
    return ok();
  } catch (err) {
    return fail(err);
  }
}
