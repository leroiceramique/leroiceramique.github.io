import { requirePerm } from "@/lib/auth";
import { query } from "@/lib/db";
import { ok, fail } from "@/lib/api";

// GET /api/movements?type=&product_id=&mine=1 — سجل الحركة (صلاحية movements)
export async function GET(req: Request) {
  try {
    const user = await requirePerm("movements");
    const url = new URL(req.url);
    const type = url.searchParams.get("type");
    const productId = url.searchParams.get("product_id");
    const mine = url.searchParams.get("mine") === "1";

    const conds: string[] = [];
    const params: unknown[] = [];
    if (type === "add" || type === "remove" || type === "reconcile") {
      params.push(type);
      conds.push(`t.type = $${params.length}`);
    }
    if (productId && /^\d+$/.test(productId)) {
      params.push(Number(productId));
      conds.push(`t.product_id = $${params.length}`);
    }
    if (mine) {
      params.push(user.id);
      conds.push(`t.user_id = $${params.length}`);
    }
    const where = conds.length ? `WHERE ${conds.join(" AND ")}` : "";

    const rows = await query(
      `SELECT t.id, t.type, t.quantity, t.date::text, t.reason,
              p.name AS product_name, p.id AS product_id,
              u.first_name AS user_name, u.username AS user_username
       FROM transactions t
       JOIN products p ON p.id = t.product_id
       JOIN users u ON u.id = t.user_id
       ${where}
       ORDER BY t.date DESC
       LIMIT 120`,
      params
    );
    return ok({ movements: rows });
  } catch (err) {
    return fail(err);
  }
}
