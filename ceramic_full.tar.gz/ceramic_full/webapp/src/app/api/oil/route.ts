import { requireUser, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { userIsAdmin } from "@/lib/perm";
import { query, queryOne } from "@/lib/db";
import { ok, fail, readBody, toNum, requireStr } from "@/lib/api";

// GET /api/oil — بطاقة حالة زيت الرافعة + القراءات + السجل
// حساب المعدل مطابق لمنطق oil_compute_rate (v22):
//   المعدل = (الحالي − خط الأساس) / الأيام بين لحظتي القياسين
//   وأي فاصل أقل من يوم واحد يُتجاهل (OIL_MIN_RATE_DAYS)
export async function GET() {
  try {
    await requireUser();
    const st = await queryOne<{
      baseline_hours: string;
      last_change_at: string | null;
      current_hours: string | null;
      current_hours_at: string | null;
    }>(
      `SELECT baseline_hours::text, last_change_at::text,
              current_hours::text, current_hours_at::text
       FROM oil_status WHERE id = 1`
    );

    let summary: Record<string, unknown> | null = null;
    if (st) {
      const baseline = Number(st.baseline_hours);
      const current = st.current_hours === null ? null : Number(st.current_hours);
      let rate: number | null = null;
      let predictedDate: string | null = null;
      if (current !== null && st.last_change_at && st.current_hours_at) {
        const t0 = new Date(st.last_change_at).getTime();
        const t1 = new Date(st.current_hours_at).getTime();
        const days = (t1 - t0) / 86_400_000;
        if (days >= 1.0 && current >= baseline) {
          rate = (current - baseline) / days;
          const remaining = 250 - (current - baseline); // نافذة التنبؤ 250 ساعة
          if (remaining > 0 && rate > 0) {
            const eta = new Date(Date.now() + (remaining / rate) * 86_400_000);
            predictedDate = eta.toISOString();
          }
        }
      }
      summary = {
        baseline,
        current,
        since_change: current === null ? null : current - baseline,
        last_change_at: st.last_change_at,
        current_hours_at: st.current_hours_at,
        rate_per_day: rate === null ? null : Number(rate.toFixed(2)),
        predicted_250_at: predictedDate,
      };
    }

    const readings = await query(
      `SELECT reading::text, read_at::text, by_name FROM oil_readings
       ORDER BY read_at DESC LIMIT 12`
    );
    const log = await query(
      `SELECT changed_at::text, hours_at_change::text, recorded_by_name, note
       FROM oil_log ORDER BY changed_at DESC LIMIT 12`
    );
    return ok({ status: summary, readings, log });
  } catch (err) {
    return fail(err);
  }
}

// POST /api/oil — {action: "reading"|"change", ...}
// reading ← إدارة أو عامل مخزون | change ← إدارة فقط (كالبوت)
export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const isAdmin = userIsAdmin(user);
    const b = await readBody<{ action?: string; reading?: unknown; hours?: unknown; note?: string }>(
      req
    );
    const action = b.action;
    if (action !== "reading" && action !== "change")
      throw new ApiError("إجراء غير معروف", 400);

    if (action === "reading") {
      if (!isAdmin && user.role !== "stock")
        throw new ApiError("تسجيل القراءة متاح للإدارة وعامل المخزون", 403);
      const reading = toNum(b.reading, "قراءة العداد");
      if (reading < 0) throw new ApiError("القراءة لا يمكن أن تكون سالبة", 400);
      const name = user.first_name || user.username || "مستخدم ويب";
      await query("INSERT INTO oil_readings (reading, by_name) VALUES ($1, $2)", [reading, name]);
      await query(
        `UPDATE oil_status
         SET current_hours = $1, current_hours_at = NOW(), updated_at = NOW()
         WHERE id = 1`,
        [reading]
      );
      await logAction(user.id, "oil_reading", String(reading));
      return ok();
    }

    // change — تسجيل تغيير زيت جديد (خط أساس جديد — لا يُؤرشف في القراءات)
    if (!isAdmin) throw new ApiError("تغيير الزيت متاح للإدارة فقط", 403);
    const hours = toNum(b.hours, "ساعات العمل عند التغيير");
    if (hours < 0) throw new ApiError("الساعات لا يمكن أن تكون سالبة", 400);
    const note =
      b.note === undefined || String(b.note).trim() === "" ? null : requireStr(b.note, "الملاحظة", 500);
    const name = user.first_name || user.username || "مستخدم ويب";

    await query("UPDATE oil_status SET confirm_worker_id = NULL, confirm_requested_at = NULL, confirm_confirmed = FALSE WHERE id = 1").catch(
      () => {}
    );
    await query(
      `INSERT INTO oil_log (hours_at_change, recorded_by_name, note) VALUES ($1, $2, $3)`,
      [hours, name, note]
    );
    await query(
      `UPDATE oil_status
       SET baseline_hours = $1, last_change_at = NOW(),
           current_hours = $1, current_hours_at = NOW(),
           predict_sent_at = NULL, notified_200_date = NULL, notified_250_at = NULL,
           updated_at = NOW()
       WHERE id = 1`,
      [hours]
    );
    await logAction(user.id, "oil_change", String(hours));
    return ok();
  } catch (err) {
    return fail(err);
  }
}
