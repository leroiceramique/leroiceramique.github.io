import { requireAdmin, hashPassword, ApiError, destroyUserSessions } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { ROLES, isProtectedTelegramId } from "@/lib/perm";
import { query, queryOne } from "@/lib/db";
import { ok, fail, readBody, requireStr } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

// PATCH /api/users/:id — إجراء على مستخدم (إدارة فقط)
// {action: "role"|"active"|"password", ...}
// الحمايات مطابقة للبوت v23:
//  • لا تعديل للحسابات المحمية (ADMIN_IDS/OWNER_IDS)
//  • لا إجراء على النفس
//  • الطرد يتطلب فئة غير إدارية (تُنزَّل أولاً) — والإدارة لا تُطرَد
//  • الطرد يُبقي السجل ويلغي جلسات الويب فوراً
//  • الفئة admin تُمنح عبر متغيرات البيئة فقط
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const admin = await requireAdmin();
    const { id } = await ctx.params;
    const uid = Number(id);
    if (!Number.isInteger(uid) || uid <= 0) throw new ApiError("معرّف غير صالح", 400);

    const target = await queryOne<{
      id: number;
      telegram_id: string;
      username: string | null;
      first_name: string | null;
      role: string;
      active: boolean;
    }>(
      "SELECT id, telegram_id::text, username, first_name, role, active FROM users WHERE id = $1",
      [uid]
    );
    if (!target) throw new ApiError("المستخدم غير موجود", 404);

    const tg = Number(target.telegram_id);
    const label = `${target.first_name ?? ""} (@${target.username ?? "—"})`;

    if (isProtectedTelegramId(tg))
      throw new ApiError("هذا حساب محمي من متغيرات البيئة — لا يمكن تعديله", 403);
    if (target.id === admin.id)
      throw new ApiError("لا يمكنك تنفيذ إجراء إداري على نفسك", 400);

    const b = await readBody<{
      action?: string;
      role?: string;
      active?: boolean;
      password?: string;
    }>(req);

    if (b.action === "role") {
      const role = requireStr(b.role, "الفئة", 20);
      if (!(ROLES as readonly string[]).includes(role))
        throw new ApiError("فئة غير معروفة", 400);
      if (role === "admin")
        throw new ApiError("فئة مدير النظام تُمنح عبر متغيرات البيئة فقط", 400);
      if (role === target.role) throw new ApiError("المستخدم بهذه الفئة بالفعل", 400);

      // عند تخفيض فئة إدارية → إلغاء جلسات الويب (صلاحياتها تغيّرت)
      const wasAdmin = target.role === "admin" || target.role === "manager";
      await query("UPDATE users SET role = $1 WHERE id = $2", [role, uid]);
      if (wasAdmin) await destroyUserSessions(uid);
      await logAction(admin.id, "user_role", `${label}: ${target.role} → ${role}`);
      return ok({ message: `تم تحديث الفئة إلى ${role}` });
    }

    if (b.action === "active") {
      if (typeof b.active !== "boolean") throw new ApiError("قيمة الحالة غير صالحة", 400);

      if (b.active === false) {
        if (target.role === "admin" || target.role === "manager")
          throw new ApiError("لا يمكن طرد فئة إدارية — نزّل فئتها أولاً ثم أعد المحاولة", 403);
        if (!target.active) throw new ApiError("الحساب مطرود بالفعل", 400);
        await query("UPDATE users SET active = FALSE WHERE id = $1", [uid]);
        await destroyUserSessions(uid);
        await logAction(admin.id, "user_kick", label);
        return ok({ message: "تم طرد المستخدم وإيقاف وصوله" });
      }

      if (target.active) throw new ApiError("الحساب نشط بالفعل", 400);
      await query("UPDATE users SET active = TRUE WHERE id = $1", [uid]);
      await logAction(admin.id, "user_unban", label);
      return ok({ message: "تم إعادة تنشيط الحساب" });
    }

    if (b.action === "password") {
      const password = requireStr(b.password, "كلمة المرور", 255);
      if (password.length < 4)
        throw new ApiError("كلمة المرور يجب أن تكون 4 أحرف على الأقل", 400);
      await query(
        `INSERT INTO web_auth (user_id, password_hash, updated_at)
         VALUES ($1, $2, NOW())
         ON CONFLICT (user_id) DO UPDATE SET password_hash = $2, updated_at = NOW()`,
        [uid, hashPassword(password)]
      );
      await destroyUserSessions(uid);
      await logAction(admin.id, "user_password_set", label);
      return ok({ message: "تم تعيين كلمة مرور الويب وإلغاء جلساته المفتوحة" });
    }

    throw new ApiError("إجراء غير معروف", 400);
  } catch (err) {
    return fail(err);
  }
}
