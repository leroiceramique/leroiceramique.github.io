import { requireAdmin, hashPassword, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { ROLES, isProtectedTelegramId } from "@/lib/perm";
import { query } from "@/lib/db";
import { ok, fail, readBody, requireStr } from "@/lib/api";

// GET /api/users — لوحة المستخدمين (إدارة فقط)
export async function GET() {
  try {
    await requireAdmin();
    const rows = await query(
      `SELECT u.id, u.telegram_id::text, u.username, u.first_name, u.role, u.active,
              u.created_at::text,
              (w.user_id IS NOT NULL) AS has_web_password
       FROM users u
       LEFT JOIN web_auth w ON w.user_id = u.id
       ORDER BY u.active DESC, u.created_at ASC
       LIMIT 300`
    );
    const users = rows.map((r) => ({
      ...r,
      protected: isProtectedTelegramId(Number(r.telegram_id)),
    }));
    const counters = {
      total: users.length,
      admins: users.filter((u) => u.role === "admin" || u.role === "manager").length,
      kicked: users.filter((u) => !u.active).length,
      pending: users.filter((u) => u.role === "pending").length,
    };
    return ok({ users, counters });
  } catch (err) {
    return fail(err);
  }
}

// POST /api/users — إضافة مستخدم ويب (لا يتطلب تلغرام إطلاقاً)
// telegram_id اصطناعي سالب حتى لا يتصادم مع حسابات تلغرام أبداً
export async function POST(req: Request) {
  try {
    const admin = await requireAdmin();
    const b = await readBody<{
      username?: string;
      first_name?: string;
      role?: string;
      password?: string;
    }>(req);
    const username = requireStr(b.username, "اسم المستخدم", 255)
      .replace(/@/g, "")
      .trim();
    if (!/^[\w.\- ]+$/.test(username))
      throw new ApiError("اسم المستخدم يحتوي رموزاً غير مسموحة", 400);
    const firstName = requireStr(b.first_name, "الاسم الظاهر", 255);
    const role = requireStr(b.role, "الفئة", 20);
    if (!(ROLES as readonly string[]).includes(role))
      throw new ApiError("فئة غير معروفة", 400);
    if (role === "admin")
      throw new ApiError("فئة مدير النظام تُمنح عبر متغيرات البيئة فقط", 400);
    const password = requireStr(b.password, "كلمة المرور", 255);
    if (password.length < 4) throw new ApiError("كلمة المرور يجب أن تكون 4 أحرف على الأقل", 400);

    const dup = await query("SELECT id FROM users WHERE LOWER(username) = LOWER($1)", [username]);
    if (dup.length > 0) throw new ApiError("اسم المستخدم محجوز مسبقاً", 409);

    const minRow = await query<{ m: string | null }>(
      "SELECT MIN(telegram_id)::text AS m FROM users WHERE telegram_id < 0"
    );
    const syntheticTid = Number(minRow[0]?.m ?? 0) - 1; // -1, -2, -3 …

    const created = await query<{ id: number }>(
      `INSERT INTO users (telegram_id, username, first_name, role, active)
       VALUES ($1, $2, $3, $4, TRUE) RETURNING id`,
      [syntheticTid, username, firstName, role]
    );
    await query("INSERT INTO web_auth (user_id, password_hash) VALUES ($1, $2)", [
      created[0].id,
      hashPassword(password),
    ]);
    await logAction(admin.id, "user_create_web", `@${username} ${role}`);
    return ok({ id: created[0].id });
  } catch (err) {
    return fail(err);
  }
}
