import { requireUser, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { userIsAdmin } from "@/lib/perm";
import { query, withTransaction } from "@/lib/db";
import { ok, fail, readBody } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

// PATCH /api/invoices/:id — اعتماد/إلغاء فاتورة (إدارة فقط)
// الاعتماد يخصم الكميات من المخزون ويسجل الحركة (إخراج — فاتورة #N)
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    if (!userIsAdmin(user)) throw new ApiError("اعتماد الفواتير متاح للإدارة فقط", 403);

    const { id } = await ctx.params;
    const iid = Number(id);
    if (!Number.isInteger(iid) || iid <= 0) throw new ApiError("معرّف غير صالح", 400);

    const b = await readBody<{ status?: string }>(req);
    if (b.status !== "approved" && b.status !== "cancelled")
      throw new ApiError("حالة غير صالحة", 400);

    const inv = await query<{ status: string; customer_name: string }>(
      "SELECT status, customer_name FROM invoices WHERE id = $1",
      [iid]
    );
    if (inv.length === 0) throw new ApiError("الفاتورة غير موجودة", 404);
    if (inv[0].status === "approved" && b.status === "approved")
      throw new ApiError("الفاتورة معتمدة مسبقاً", 409);
    if (inv[0].status === "cancelled")
      throw new ApiError("لا يمكن تعديل فاتورة ملغاة", 409);

    await withTransaction(async (tx) => {
      await tx.query(
        `UPDATE invoices
         SET status = $1::varchar,
             approved_at = CASE WHEN $1::varchar = 'approved' THEN NOW() ELSE approved_at END
         WHERE id = $2`,
        [b.status, iid]
      );

      if (b.status === "approved") {
        const items = await tx.query<{ product_id: number | null; quantity: number }>(
          "SELECT product_id, quantity FROM invoice_items WHERE invoice_id = $1",
          [iid]
        );
        for (const item of items) {
          if (!item.product_id) continue;
          // خصم ما هو متوفر فقط، والنافذ يصبح تسليم معلق
          const p = await tx.query<{ quantity: number }>(
            "SELECT quantity FROM products WHERE id = $1 FOR UPDATE",
            [item.product_id]
          );
          if (p.length === 0) continue;
          const take = Math.min(item.quantity, p[0].quantity);
          if (take > 0) {
            await tx.query("UPDATE products SET quantity = quantity - $1 WHERE id = $2", [
              take,
              item.product_id,
            ]);
            await tx.query(
              `INSERT INTO transactions (product_id, type, quantity, user_id, reason)
               VALUES ($1, 'remove', $2, $3, $4)`,
              [item.product_id, take, user.id, `فاتورة #${iid} — ${inv[0].customer_name}`]
            );
          }
          const shortfall = item.quantity - take;
          if (shortfall > 0) {
            await tx.query(
              `INSERT INTO pending_deliveries (user_id, product_id, pending_qty)
               VALUES ($1, $2, $3)`,
              [user.id, item.product_id, shortfall]
            );
          }
        }
      }
    });

    await logAction(user.id, `invoice_${b.status}`, `#${iid}`);
    return ok();
  } catch (err) {
    return fail(err);
  }
}
