import { requireUser, effectivePerms, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { userIsAdmin } from "@/lib/perm";
import { query, withTransaction } from "@/lib/db";
import { ok, fail, readBody, requireStr, toPosInt, toNum } from "@/lib/api";

// GET /api/invoices — قائمة الفواتير (+ عناصرها)
// الإدارة ترى الكل، صاحب صلاحية invoice يرى فواتيره
export async function GET() {
  try {
    const user = await requireUser();
    const perms = await effectivePerms(user);
    const isAdmin = userIsAdmin(user);
    if (!isAdmin && !perms.includes("invoice"))
      throw new ApiError("لا تملك صلاحية عرض الفواتير", 403);

    const invoices = await query(
      `SELECT i.id, i.customer_name, i.total_amount::text, i.status, i.created_at::text,
              i.approved_at::text, w.first_name AS worker_name, a.first_name AS admin_name,
              i.worker_id, i.admin_id
       FROM invoices i
       LEFT JOIN users w ON w.id = i.worker_id
       JOIN users a ON a.id = i.admin_id
       ${isAdmin ? "" : "WHERE i.worker_id = $1 OR i.admin_id = $1"}
       ORDER BY i.created_at DESC LIMIT 100`,
      isAdmin ? [] : [user.id]
    );

    const items = await query(
      `SELECT ii.invoice_id, ii.product_name, ii.quantity, ii.unit_price::text, ii.subtotal::text, ii.product_id
       FROM invoice_items ii`
    );
    const byInvoice = new Map<number, unknown[]>();
    for (const it of items) {
      const arr = byInvoice.get(it.invoice_id) ?? [];
      arr.push(it);
      byInvoice.set(it.invoice_id, arr);
    }
    const result = invoices.map((inv) => ({ ...inv, items: byInvoice.get(inv.id) ?? [] }));
    return ok({ invoices: result, is_admin: isAdmin });
  } catch (err) {
    return fail(err);
  }
}

// POST /api/invoices — إنشاء فاتورة (صلاحية invoice)
// {customer_name, items: [{product_id, quantity, unit_price}]}
export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const perms = await effectivePerms(user);
    if (!userIsAdmin(user) && !perms.includes("invoice"))
      throw new ApiError("لا تملك صلاحية إنشاء فاتورة", 403);

    const b = await readBody<{
      customer_name?: string;
      items?: Array<{ product_id?: unknown; quantity?: unknown; unit_price?: unknown }>;
    }>(req);
    const customer = requireStr(b.customer_name, "اسم الزبون", 500);
    if (!Array.isArray(b.items) || b.items.length === 0)
      throw new ApiError("الفاتورة فارغة — أضف سلعاً أولاً", 400);
    if (b.items.length > 50) throw new ApiError("الحد الأقصى 50 بنداً للفاتورة", 400);

    // التحقق من السلع وحساب المجاميع
    const validated: Array<{ pid: number; name: string; qty: number; price: number }> = [];
    for (const item of b.items) {
      const pid = toPosInt(item.product_id, "معرّف السلعة");
      const qty = toPosInt(item.quantity, "الكمية");
      const price = toNum(item.unit_price, "السعر");
      if (price < 0) throw new ApiError("السعر لا يمكن أن يكون سالباً", 400);
      const p = await query<{ name: string }>("SELECT name FROM products WHERE id = $1", [pid]);
      if (p.length === 0) throw new ApiError("أحد البنود يشير لسلعة غير موجودة", 400);
      validated.push({ pid, name: p[0].name, qty, price });
    }
    const total = validated.reduce((s, v) => s + v.qty * v.price, 0);

    const invId = await withTransaction<number>(async (tx) => {
      const created = await tx.query<{ id: number }>(
        `INSERT INTO invoices (customer_name, worker_id, admin_id, total_amount)
         VALUES ($1, $2, $2, $3) RETURNING id`,
        [customer, user.id, total.toFixed(2)]
      );
      const id = created[0].id;
      for (const v of validated) {
        await tx.query(
          `INSERT INTO invoice_items (invoice_id, product_id, product_name, quantity, unit_price, subtotal)
           VALUES ($1, $2, $3, $4, $5, $6)`,
          [id, v.pid, v.name, v.qty, v.price.toFixed(2), (v.qty * v.price).toFixed(2)]
        );
      }
      return id;
    });

    await logAction(user.id, "invoice_create", `#${invId} ${customer} — ${total.toFixed(2)}`);
    return ok({ id: invId, total: Number(total.toFixed(2)) });
  } catch (err) {
    return fail(err);
  }
}
