import { requireUser, verifyPassword, hashPassword, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { query, queryOne } from "@/lib/db";
import { ok, fail, readBody, requireStr } from "@/lib/api";
import { cookies } from "next/headers";
import { SESSION_COOKIE, tokenHash } from "@/lib/auth";

// POST /api/profile — تغيير كلمة مروري {current_password, new_password}
export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const b = await readBody<{ current_password?: string; new_password?: string }>(req);
    const current = requireStr(b.current_password, "كلمة المرور الحالية", 255);
    const next = requireStr(b.new_password, "كلمة المرور الجديدة", 255);
    if (next.length < 4) throw new ApiError("كلمة المرور الجديدة يجب أن تكون 4 أحرف على الأقل", 400);
    if (next === current) throw new ApiError("كلمة المرور الجديدة مطابقة للحالية", 400);

    const row = await queryOne<{ password_hash: string }>(
      "SELECT password_hash FROM web_auth WHERE user_id = $1",
      [user.id]
    );
    if (!row) throw new ApiError("لا توجد كلمة مرور ويب لحسابك — تواصل مع الإدارة", 400);
    if (!verifyPassword(current, row.password_hash))
      throw new ApiError("كلمة المرور الحالية غير صحيحة", 401);

    await query(
      `UPDATE web_auth SET password_hash = $1, updated_at = NOW() WHERE user_id = $2`,
      [hashPassword(next), user.id]
    );

    // إلغاء كل الجلسات الأخرى والاحتفاظ بالجلسة الحالية
    const store = await cookies();
    const cur = store.get(SESSION_COOKIE)?.value;
    if (cur) {
      await query(
        "DELETE FROM web_sessions WHERE user_id = $1 AND token <> $2",
        [user.id, tokenHash(cur)]
      );
    }
    await logAction(user.id, "password_change", `@${user.username}`);
    return ok({ message: "تم تغيير كلمة المرور بنجاح" });
  } catch (err) {
    return fail(err);
  }
}
