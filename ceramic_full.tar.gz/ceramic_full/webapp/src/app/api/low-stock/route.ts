import { requirePerm } from "@/lib/auth";
import { query } from "@/lib/db";
import { ok, fail } from "@/lib/api";

// GET /api/low-stock — المخزون المنخفض (صلاحية low_stock)
export async function GET() {
  try {
    await requirePerm("low_stock");
    const rows = await query(
      `SELECT id, name, quantity, location, minimum_stock, selling_price::text
       FROM products
       WHERE quantity <= minimum_stock
       ORDER BY (quantity - minimum_stock) ASC, name ASC`
    );
    return ok({ products: rows });
  } catch (err) {
    return fail(err);
  }
}
