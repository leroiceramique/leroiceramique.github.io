import { getSessionUser, effectivePerms } from "@/lib/auth";
import { userIsAdmin } from "@/lib/perm";
import { ok, fail } from "@/lib/api";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) return ok({ user: null });
    const perms = await effectivePerms(user);
    const isAdmin = userIsAdmin(user);
    return ok({
      user,
      perms,
      is_admin: isAdmin,
      // البائع الخارجي يرى التوفر دون كميات (مطابق للبوت)
      hide_qty: user.role === "external" && !isAdmin,
    });
  } catch (err) {
    return fail(err);
  }
}
