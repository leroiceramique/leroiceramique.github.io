import { requireUser, requirePerm, effectivePerms, type SessionUser } from "@/lib/auth";
import { userIsAdmin } from "@/lib/perm";
import { query, logAction } from "@/lib/db";
import { ok, fail, readBody, requireStr, toInt, toNum } from "@/lib/api";
import type { Perm } from "@/lib/perm";

// GET /api/products?q=... — القائمة/البحث (البائع الخارجي يرى التوفر دون كميات)
export async function GET(req: Request) {
  try {
    const user: SessionUser = await requireUser();
    const perms = await effectivePerms(user);
    const isAdmin = userIsAdmin(user);
    const hideQty = user.role === "external" && !isAdmin;

    const url = new URL(req.url);
    const q = (url.searchParams.get("q") || "").trim();
    const sort = url.searchParams.get("sort") || "name";

    let orderBy = "name ASC";
    if (sort === "qty") orderBy = hideQty ? "name ASC" : "quantity ASC, name ASC";
    else if (sort === "new") orderBy = "created_at DESC, name ASC";

    const where = q ? "WHERE name ILIKE $1" : "";
    const params = q ? [`%${q}%`] : [];
    const rows = await query<{
      id: number;
      name: string;
      quantity: number;
      location: string | null;
      minimum_stock: number;
      selling_price: string;
      created_at: string;
    }>(
      `SELECT id, name, quantity, location, minimum_stock, selling_price::text, created_at::text
       FROM products ${where} ORDER BY ${orderBy} LIMIT 300`,
      params
    );

    if (hideQty) {
      // التوفر فقط دون كميات — مطابق لسلوك البوت مع البائع الخارجي
      return ok({
        hide_qty: true,
        products: rows.map((p) => ({
          id: p.id,
          name: p.name,
          location: p.location,
          available: p.quantity > 0,
        })),
      });
    }
    return ok({ hide_qty: false, perms, products: rows });
  } catch (err) {
    return fail(err);
  }
}

// POST /api/products — إضافة سلعة (صلاحية add_product)
export async function POST(req: Request) {
  try {
    const user = await requirePerm("add_product");
    const b = await readBody<Record<string, unknown>>(req);
    const name = requireStr(b.name, "اسم السلعة", 500);
    const quantity = b.quantity === undefined || b.quantity === "" ? 0 : toInt(b.quantity, "الكمية");
    if (quantity < 0) throw Object.assign(new Error("الكمية لا يمكن أن تكون سالبة"), { status: 400 });
    const location = typeof b.location === "string" ? b.location.trim().slice(0, 255) : "";
    const minimum = b.minimum_stock === undefined || b.minimum_stock === "" ? 5 : toInt(b.minimum_stock, "الحد الأدنى");
    const price = b.selling_price === undefined || b.selling_price === "" ? 0 : toNum(b.selling_price, "السعر");
    if (minimum < 0 || price < 0) throw Object.assign(new Error("قيم سالبة غير مسموحة"), { status: 400 });

    const dup = await query("SELECT id FROM products WHERE LOWER(name) = LOWER($1) LIMIT 1", [name]);
    if (dup.length > 0)
      return Response.json({ ok: false, error: "توجد سلعة بنفس الاسم بالفعل" }, { status: 409 });

    const created = await query<{ id: number }>(
      `INSERT INTO products (name, quantity, location, minimum_stock, selling_price)
       VALUES ($1, $2, $3, $4, $5) RETURNING id`,
      [name, quantity, location, minimum, price.toFixed(2)]
    );
    if (quantity > 0) {
      await query(
        `INSERT INTO transactions (product_id, type, quantity, user_id, reason)
         VALUES ($1, 'add', $2, $3, $4)`,
        [created[0].id, quantity, user.id, "إضافة سلعة جديدة"]
      );
    }
    await logAction(user.id, "product_add", name);
    return ok({ id: created[0].id });
  } catch (err) {
    return fail(err);
  }
}

// ملاحظة: تعديل/حذف/كميات سلعة محددة في المسارات الفرعية
export const dynamic = "force-dynamic";
