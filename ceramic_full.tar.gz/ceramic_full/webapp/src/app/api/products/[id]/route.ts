import { requireUser, requirePerm, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { userIsAdmin } from "@/lib/perm";
import { query } from "@/lib/db";
import { ok, fail, readBody, requireStr, toInt, toNum } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

// PATCH /api/products/:id — تعديل سلعة (صلاحية edit_product)
export async function PATCH(req: Request, ctx: Ctx) {
  try {
    const user = await requirePerm("edit_product");
    const { id } = await ctx.params;
    const pid = toInt(id, "المعرّف");
    const b = await readBody<Record<string, unknown>>(req);

    const current = await query<{ id: number }>("SELECT id FROM products WHERE id = $1", [pid]);
    if (current.length === 0) throw new ApiError("السلعة غير موجودة", 404);

    const fields: string[] = [];
    const params: unknown[] = [];
    if (b.name !== undefined) {
      fields.push(`name = $${params.length + 1}`);
      params.push(requireStr(b.name, "اسم السلعة", 500));
    }
    if (b.location !== undefined) {
      fields.push(`location = $${params.length + 1}`);
      params.push(String(b.location ?? "").trim().slice(0, 255));
    }
    if (b.minimum_stock !== undefined) {
      const m = toInt(b.minimum_stock, "الحد الأدنى");
      if (m < 0) throw new ApiError("الحد الأدنى لا يمكن أن يكون سالباً", 400);
      fields.push(`minimum_stock = $${params.length + 1}`);
      params.push(m);
    }
    if (b.selling_price !== undefined) {
      const p = toNum(b.selling_price, "السعر");
      if (p < 0) throw new ApiError("السعر لا يمكن أن يكون سالباً", 400);
      fields.push(`selling_price = $${params.length + 1}`);
      params.push(p.toFixed(2));
    }
    if (fields.length === 0) throw new ApiError("لا توجد حقول للتعديل", 400);

    params.push(pid);
    await query(`UPDATE products SET ${fields.join(", ")} WHERE id = $${params.length}`, params);
    await logAction(user.id, "product_edit", `#${pid}`);
    return ok();
  } catch (err) {
    return fail(err);
  }
}

// DELETE /api/products/:id — حذف سلعة (إدارة فقط، كما في البوت)
export async function DELETE(_req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    if (!userIsAdmin(user)) throw new ApiError("حذف السلع متاح للإدارة فقط", 403);
    const { id } = await ctx.params;
    const pid = toInt(id, "المعرّف");
    const exists = await query<{ name: string }>("SELECT name FROM products WHERE id = $1", [pid]);
    if (exists.length === 0) throw new ApiError("السلعة غير موجودة", 404);
    try {
      await query("DELETE FROM products WHERE id = $1", [pid]);
    } catch (e) {
      if (e instanceof Error && /violates foreign key/i.test(e.message))
        throw new ApiError(
          "لا يمكن حذف سلعة لها حركات مسجلة — يمكنك تصفير كميتها بدلاً من الحذف",
          409
        );
      throw e;
    }
    await logAction(user.id, "product_delete", exists[0].name);
    return ok();
  } catch (err) {
    return fail(err);
  }
}
