import { requireUser, effectivePerms, ApiError } from "@/lib/auth";
import { logAction } from "@/lib/db";
import { userIsAdmin } from "@/lib/perm";
import { withTransaction } from "@/lib/db";
import { ok, fail, readBody, toPosInt, requireStr } from "@/lib/api";

type Ctx = { params: Promise<{ id: string }> };

// POST /api/products/:id/qty
// {type: "add"|"remove"|"reconcile", quantity, reason?}
// add ← صلاحية add_qty | remove ← صلاحية remove | reconcile ← إدارة فقط
// عند الإخراج بكمية أكبر من المتوفر: يُسجَّل طلب تسليم معلق
// (pending_deliveries) بنفس منطق البوت.
export async function POST(req: Request, ctx: Ctx) {
  try {
    const user = await requireUser();
    const perms = await effectivePerms(user);
    const isAdmin = userIsAdmin(user);

    const { id } = await ctx.params;
    const pid = Number(id);
    if (!Number.isInteger(pid) || pid <= 0) throw new ApiError("معرّف غير صالح", 400);

    const b = await readBody<{ type?: string; quantity?: unknown; reason?: string }>(req);
    const type = b.type;
    if (type !== "add" && type !== "remove" && type !== "reconcile")
      throw new ApiError("نوع الحركة غير معروف", 400);
    const qty = toPosInt(b.quantity, "الكمية");

    if (type === "add" && !perms.includes("add_qty"))
      throw new ApiError("لا تملك صلاحية إضافة كمية", 403);
    if (type === "remove" && !perms.includes("remove"))
      throw new ApiError("لا تملك صلاحية إخراج كمية", 403);
    if (type === "reconcile" && !isAdmin)
      throw new ApiError("التسوية/الجرد متاح للإدارة فقط", 403);

    const reason =
      b.reason === undefined || b.reason === null || String(b.reason).trim() === ""
        ? null
        : requireStr(b.reason, "السبب", 200);

    const result = await withTransaction<{ pending?: number }>(async (tx) => {
      const rows = await tx.query<{ quantity: number; name: string }>(
        "SELECT quantity, name FROM products WHERE id = $1 FOR UPDATE",
        [pid]
      );
      if (rows.length === 0) throw new ApiError("السلعة غير موجودة", 404);
      const product = rows[0];

      if (type === "add") {
        await tx.query("UPDATE products SET quantity = quantity + $1 WHERE id = $2", [qty, pid]);
        await tx.query(
          `INSERT INTO transactions (product_id, type, quantity, user_id, reason)
           VALUES ($1, 'add', $2, $3, $4)`,
          [pid, qty, user.id, reason ?? "إضافة كمية"]
        );
        return {};
      }

      if (type === "remove") {
        if (qty > product.quantity) {
          const shortfall = qty - product.quantity;
          await tx.query(
            `INSERT INTO pending_deliveries (user_id, product_id, pending_qty)
             VALUES ($1, $2, $3)`,
            [user.id, pid, shortfall]
          );
          if (product.quantity > 0) {
            await tx.query("UPDATE products SET quantity = 0 WHERE id = $1", [pid]);
            await tx.query(
              `INSERT INTO transactions (product_id, type, quantity, user_id, reason)
               VALUES ($1, 'remove', $2, $3, $4)`,
              [pid, product.quantity, user.id, (reason ?? "إخراج كمية") + " (النافذ)"]
            );
          }
          return { pending: shortfall };
        }
        await tx.query("UPDATE products SET quantity = quantity - $1 WHERE id = $2", [qty, pid]);
        await tx.query(
          `INSERT INTO transactions (product_id, type, quantity, user_id, reason)
           VALUES ($1, 'remove', $2, $3, $4)`,
          [pid, qty, user.id, reason ?? "إخراج كمية"]
        );
        return {};
      }

      // reconcile — الجرد: تعيين الكمية الفعلية
      const diff = qty - product.quantity;
      await tx.query("UPDATE products SET quantity = $1 WHERE id = $2", [qty, pid]);
      await tx.query(
        `INSERT INTO transactions (product_id, type, quantity, user_id, reason)
         VALUES ($1, 'reconcile', $2, $3, $4)`,
        [pid, diff, user.id, reason ?? "تسوية جرد"]
      );
      return {};
    });

    if (result.pending) {
      await logAction(user.id, "qty_remove_pending", `#${pid} نافذ ${result.pending}`);
      return ok({
        pending: result.pending,
        warning: `المتوفر كان أقل من المطلوب — سُجّلت ${result.pending} وحدة كطلب تسليم معلق`,
      });
    }
    await logAction(user.id, `qty_${type}`, `#${pid} × ${qty}`);
    return ok();
  } catch (err) {
    return fail(err);
  }
}
