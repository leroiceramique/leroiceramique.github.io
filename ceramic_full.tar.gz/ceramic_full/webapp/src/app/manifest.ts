import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "مخزون السيراميك — إدارة المخزون",
    short_name: "مخزون السيراميك",
    description:
      "نظام إدارة مخزون السيراميك: المخزون، الحركة، طلبات التوريد، الفواتير، المستخدمون — متزامن مع بوت تلغرام على نفس قاعدة البيانات.",
    id: "/",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    dir: "rtl",
    lang: "ar",
    background_color: "#FBF6F0",
    theme_color: "#B05A2E",
    categories: ["business", "productivity"],
    icons: [
      {
        src: "/icons/icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/maskable-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
