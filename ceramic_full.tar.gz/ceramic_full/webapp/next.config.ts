import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  // pg مكتبة اتصال بالقاعدة — تبقى خارجية لضمان عملها في بناء الإنتاج
  serverExternalPackages: ["pg"],
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
